# Test matrix — rebuild 0.1.0

Status key: **PASS/static** = inspected source/assets; **PASS/mock** = executed Lua against adapted mocks; **PENDING/iOS** = not run in Gen1Recomp. A row may have passing internal checks and still need live testing. No iOS pass is implied.

First test: separate fresh-save diagnostic cart with candidate + installed Kaizo + Crystal; old unified/split mods OFF; Wilds OFF; Voxel may remain ON and user-adjustable. Then enable Wilds for follower testing. External mods are not bundled.

| Test | Local evidence | Required live result |
|---|---|---|
| Manifest, entry, Lua syntax | PASS/static, Lua 5.4 load | Candidate imports independently as 0.1.0 |
| Exactly three custom species | PASS/mock duplicate-registration guard | No duplicate dex entries |
| Fresh Psydren/Fennekin/Grass acquisition | PASS/mock shared gift path for Psydren/Fennekin/Treecko; script registration | PENDING/iOS: Oak flow, choice/cancel/full party/box and tutorial |
| Genuine shiny DV/flag | PASS/mock, HP DV 8 | Shiny marker on all three gifts |
| Shiny reveal + SFX | External owner only | PENDING/iOS: all starter lines; no duplicate/suppressed reveal |
| Lv16/Lv36 progression and Modest | PASS/static evolution records; PASS/mock identity/stat recalculation | PENDING/iOS: actual level-triggered evolution, 10% modifiers |
| Shiny evolution art | PASS/mock routing for all 3 stages × 2 palettes | PENDING/iOS: evolution animation and post-evolution battle |
| Menu/summary/icon | PASS/mock paths; PASS/static all frames nonblank | PENDING/iOS: party, box, dex, summary; no blank/incorrect art |
| Front/back size/grounding | PASS/static canvas/bottom alpha bounds, species scales only | PENDING/iOS: Psydren < Vesperis < Solipsdion; no clipping/floating/sinking, grow/reveal/context transitions |
| Treecko/Fennekin/vanilla regression | PASS/mock official paths pass through, no battle image/scale writes to Treecko | PENDING/iOS: correct official shiny color, native size/floor |
| Custom true right-facing followers | PASS/static 8-frame art; PASS/mock normal four-facing path | PENDING/iOS: all facings, walking, special clipped/OAM contexts |
| Follower shiny sparkle | PASS/mock origin/camera geometry in four facings; no unowned/player sprite sparkle | PENDING/iOS: custom + Fennekin + Grass; follower-only anchoring; dependency definition identity |
| Wilds absent | PASS/mock complete entry/post-load with no Wilds | PENDING/iOS: clean startup, no forced activation |
| Map transitions/menu/follower reload | Conditional service and native fields retained | PENDING/iOS: no lost state or stale sprite |
| Save/load/party reorder/PC | Identity code inspected; no real save engine | PENDING/iOS: shiny, Nature, Stone, gender and follower survive |
| Distance physical + special | PASS/mock 0 damage preserved, 100→75 once, next 100, reentry resets | PENDING/iOS: misses, immunity, multihit, AI preview timing |
| Reign slot/revival/live HP | PASS/mock slot 2, ally revival, live 0 HP, +20% clones | PENDING/iOS: negative-stage suppression and turn order |
| Reagent milestones/backfill | PASS/static four flag mappings | PENDING/iOS: each reward once; Bag full/retry |
| Champion gate/ritual | PASS/static script/labels | PENDING/iOS: all five steps and non-Champion rejection |
| One Stone/bind/sever/rebind | PASS/mock duplicate bind rejected, reclaim before clearing, rebind, successful/full-bag craft transaction | PENDING/iOS: Bag consumption, boxes/daycare, full-bag delivery check in the actual engine |
| Ordinary First Condition | PASS/mock threshold, 25% healing, one use, reset after benched start | PENDING/iOS: live HP display/synchronization |
| Resonance/Communion/Awakening | PASS/static + evolution metadata mock | PENDING/iOS: bind before/after evolving |
| Environments | PASS/mock neutral, ordinary Mansion interior, Cinnabar, water route, Seafoam, desert, Mt. Moon, forest | PENDING/iOS: actual map IDs/ambient fields |
| Weather override/end | PASS/mock Sun/Rain/Hail/Sand and nil→map restoration | PENDING/iOS: actual provider, mid-turn display and natural expiration |
| Seraph's Verdict | PASS/mock per-use type, shared move unchanged, Summary view restoration | PENDING/iOS: correct damage and move-selection label (unresolved) |
| Ansem selection/default | PASS/mock explicit Ansem + default Red configurations | PENDING/iOS: coexistence with installed selector |
| Ansem walk/bike/surf/fishing/front/back | PASS/static PNGs; PASS/mock field assignments | PENDING/iOS: movement, fish rod, battle throw, Trainer Card |
| Ansem portrait/Hall of Fame | Portrait asset present | PENDING/iOS/API: consumers not independently wired |
| Rival male/female/Melony | PASS/mock choice insertion and gender-dependent trainer art | PENDING/iOS: before naming, NPCs, reload, later Froakie-family continuity |
| Dynamic wild/trainer toggles | PASS/mock ranges, floors, original data unchanged, OFF, Oak exception | PENDING/iOS: actual Kaizo teams and direct scripted wild encounters |
| Voxel ON, Wilds OFF | PASS/static no Voxel code/settings writes | PENDING/iOS: Voxel can remain adjustable; nickname issue not addressed |

## Executed commands

From the review package root after extracting the candidate ZIP into `deliverables/`:

```text
python tools/run_lua.py < tests_absent.lua
python tools/run_lua.py < tests_present.lua
```

`run_lua.py` uses an installed `liblua5.4.so.0`. With a Lua executable, use `lua mock_regressions.lua deliverables/red_earth_irregular_rebuild absent red` or `... present ansem` instead. Mocks model snapshot call shapes; they are not dependency sources.
