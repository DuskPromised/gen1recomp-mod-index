# Hook and wrapper ownership

Each named hook is installed once in the candidate. Separate events may refresh different responsibilities; they do not stack copies of a renderer. The old unified/split mods are manifest conflicts. External wrapper order remains a live integration check.

| Shared surface found in history | First supplied version | Class / candidate owner | Decision |
|---|---|---|---|
| `pokemon.sprite` | 0.1 | Canonical / species art router | One route for custom normal/shiny; mon identity wins over hints. Delegate all others. |
| `pokemon.icon` | 0.1 | Canonical / species art router | Dedicated icon sheets, one wrapper. |
| `BattleState.drawPicsLayer` | 0.1 | External integration / battle art adapter | Keep one explicit custom-species image adapter; no scale/grounding writes. Legacy recolor sentinel needs Crystal validation. Removed in supplied 1.0.0; reinstated narrowly from earlier evidence. |
| `trainer.party` | 0.2 | Canonical + external / difficulty composition | One combined rival/level owner. Never stack the earlier replacement-only wrapper. |
| `battle.damage` | 0.2 | Canonical / combat calculation | One pipeline for Verdict, Reign and Distance. |
| `battle.turn_order` | 0.2 | Canonical / combat calculation | Reign-only temporary Speed clone, active-battle fallback. |
| `shiny.exports.bakeFollowerOwSheet` | 0.2 | Legacy integration | Removed. No SHINY_POKEMON or Followers EX path. |
| `Assets.image` replacement | 0.2 | Broad compatibility / regression risk | Removed entirely. All other modules keep original asset lookup. |
| `SummaryMenu.new` | 0.2 | Canonical / Summary adapter | Custom portraits only; dedicated menu image. |
| `SummaryMenu.draw` | 0.2 | Canonical / Summary adapter | Private type/move data view, restored on errors. Reject historical mutation of shared species definition. |
| `SpriteRenderer.draw` | 0.2 | Conditional external / follower adapter | Only exact primary follower definitions tagged by Wilds service; ordinary custom draws use eight-frame art. Everything else delegates. No trainer coordinates/facing offsets. Not installed if Wilds service is absent. |
| `intro.oak_speech.build` | 0.3 | Canonical / rival identity | Independent gender choice before rival name. |
| `OakSpeech.resolvePic` | 0.3 | Canonical / rival portraits | Female rival gate only. Other portraits delegate. |
| `BattleState.trainerSprite` | 0.3 | Canonical / rival portraits | Female rival classes only. Others delegate. |
| Wilds `spriteService.resolveFollowerSprite` | 1.0.0 | External / follower adapter | Conditional service interception; copies native definition before tagging. Only Irregular images change. |
| `encounter.species` | 1.0.1 | External / difficulty composition | Upward-only level copy, independent toggle. |
| `script.command` | 1.0.1 | External / difficulty composition | Only direct wild `start_battle`; copies arguments. |

## Event and data owners

- `pokemon.evolved` / `pokemon.level_up`: shiny identity, Nature and Stone progression. No species re-registration.
- `battle.started` / `battle.battler_switched` / `battle.ended`: battle lifetime, Distance arming, renewal reset, and type refresh.
- `battle.turn_ended`: live attunement refresh, First Condition, Reign stage suppression. No guessed weather countdown.
- `flag.changed`, `game.ready`, `map.entered`: milestone rewards/retry, saved rival choice, female rival NPC refresh. Native Pokémon metadata serialization is delegated to the engine.
- `intro.oak_speech.answered`: rival identity persistence.
- `mods.loaded`: a single dispatcher installs four distinct presentation adapters. It does not wrap itself or retry cumulatively.
- Content registries: one species loop, one move registration owner, one Stone owner, one Oak Lab script, one Cinnabar script.
- Field patches: Ansem selection only; default choice makes no player field patches.

## Rejected overlaps

Do not combine snapshots as runtime mods. The rebuild omits legacy image-path fallback, shiny follower baking, party-based follower guessing, player-role sparkle, manual origin fallback, shared Verdict refresh and guessed weather events. The two historical follower runtimes are not layered together. There are no Voxel or Wilds configuration writes, and no battle-scale owner outside the custom species records.
