# Audit patch — 0.1.1

One concrete integration defect was found in Claude's 0.1.0 candidate.

Wilds of Kanto v2.1.9 and current 2.2.0 copy the table returned by `resolveFollowerSprite()` before passing it to `SpriteRenderer.new()`. The candidate kept sparkle/eight-direction metadata in a weak table keyed by the original table object. That key could never match `self.def` after Wilds copied it.

Fix: attach `_redEarthFollowerMeta` to the returned definition. Wilds uses a shallow `for k,v in pairs(def)` copy, so the metadata survives. `SpriteRenderer.draw` now reads `self.def._redEarthFollowerMeta`.

No other runtime behavior was changed.

Remaining external gap: official regional starter shiny artwork remains owned by the existing `red_earth_regional_shiny_art` v1.0.5 layer for the test stack; Crystal supplies the genuine shiny reveal/SFX path but its exact custom-Irregular bypass behavior remains a live test item.


## v0.1.2 — Oak starter hook collision
Live iOS testing showed Allgen Kaizo's regional-starter `script.command` hook still owned Oak's vanilla ball flow (KANTO/JOHTO/... menu, rival Squirtle), so Psydren never appeared. The rebuild now intercepts only the three Oak ball targets at `world.talk` and runs the already-authored Psydren/Fennekin/regional-Grass scripts directly. Kaizo remains authoritative everywhere else.
