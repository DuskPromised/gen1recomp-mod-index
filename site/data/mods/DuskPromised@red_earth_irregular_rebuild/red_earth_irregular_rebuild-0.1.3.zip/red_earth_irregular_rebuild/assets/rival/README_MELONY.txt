FEMALE RIVAL — MELONY — COMPLETE

Final assets now ship in this build:

melony_front.png
- 56x56 transparent true-color trainer front
- used by Oak's intro when Female is selected
- used by RIVAL1 / RIVAL2 / RIVAL3 battle presentation

melony_overworld.png
- 16x96 transparent six-frame Gen1 walker
- frame order: DOWN, UP, LEFT, DOWN-WALK, UP-WALK, LEFT-WALK
- used by rival NPCs when Female is selected

melony_overworld_8dir.png
- 16x128 preserved derivative with authored RIGHT-facing frames as well
- retained for a possible future 8-direction rival renderer

melony_source_fullbody.png
- untouched extracted full-body source from the supplied PokeRogue strip

The code keeps a stock female-art fallback only to avoid a crash if these
assets are manually deleted.
