# Red Earth Irregular reconstruction — 0.1.0 candidate

This is a locally reconstructed test candidate, not a verified iOS release. Nothing was published or pushed. All seven implementation archives were unpacked separately; all 19 supplied checksums match. No network source was used. The engine and external mod source are absent, so mocks establish internal behavior, not external API correctness.

## Reconstruction and ownership

`tools/reconstruct.py` assembles selected responsibility blocks into an empty output tree. `SOURCE_SELECTION.json` records their original line ranges. `tools/presentation.lua` supplies the reviewed presentation adapters. There is no copy-and-patch of v1.0.1. No local runtime modules are needed. The candidate has a new ID, conflicts with the old unified/split implementations, and leaves the existing cart untouched.

| Feature | Chosen history | Reconstruction decision |
|---|---|---|
| Species, stats, moves, Lv16/Lv36 evolution | v0.1 origin, v0.5 definitions; v1.0.0 native registration | Register exactly three species once. Reject obsolete Expanded Species dependency. Preserve species-local scales: Psydren .94/.94, Vesperis 1/1, Solipsdion 1.08/1.05. These are inherited candidate values, not iOS-calibrated values. |
| Artwork | v0.1 Pokémon derivatives; v0.4 Melony; v0.5 Ansem field states | Preserve source pixels. Pokémon derivatives are byte-identical throughout the supplied history. Include normal/shiny fronts, backs, menus, icons, six-frame followers, eight-frame followers and directional assets. Masters were inspected as the authority; no replacement art generated. |
| Genuine shiny + Modest | v0.2 origin; v1.0.0 gift/DV correction | HP DV 8, explicit shiny flag, party/box native gift path. Modest recalculates from base stats, avoiding cumulative boosts. Fennekin/Grass receive no Irregular palette or Nature. Evolution maintains condition metadata. |
| Menu/icon | v1.0.0 | Dedicated menu/icon routing for both palettes. Actual mon species wins over a stale context hint. Other species delegate unchanged. |
| Battle art | narrow v0.1/v0.5 species gate | One draw adapter supplies only custom images. No renderer-wide scale, floor, send-out growth or offset edits. Legacy `_shinySpriteApplied` support is a Crystal integration uncertainty, not a verified contract. |
| Starter route and rival continuity | v1.0.0 | Keep Psydren, Fennekin and optional Kanto–Alola Grass flow; retain Froakie-family replacement. Multiple starter-family members in a rival roster remain a documented ambiguity. |
| Distance | v0.2 via v0.5 | One damage-hook owner. Positive damage consumes the 25% shield; switch-in rearms. The engine's calculation-versus-connected-hit contract needs source verification. |
| Solitary Reign | v0.4/v0.5 | Keep captured live BattleState fallback. Read active battler HP preferentially; clone stats for +20% Special/Speed calculations. Revival disables the predicate. |
| Reagents/Crucible/binding | v0.3 milestones; v1.0.0 ownership/sever | Scan party/boxes/daycare, reject simultaneous second binding, return the Stone before clearing its bond. Preserve five-stage ritual and Champion gate. Reagents are now removed only after the existing `check_item` command confirms Stone delivery; full-bag/success paths pass the script mock. |
| First Condition | v0.3 | Reset the entire per-battle consumption table, including benched Pokémon; heal against live battler HP. |
| Aetheric Transmutation | v0.2 classifier/combat | Remove guessed five-turn weather simulation. Observe snapshot-referenced battle weather fields; read them again on damage, battle start, switch and turn end. Ordinary Mansion interiors return Dragon. Exact weather lifecycle fields remain external verification. |
| Seraph’s Verdict and Summary | v0.2 mechanics; rebuilt isolated Summary view | Clone move per use. Reject v1.0.0's permanent shared move-type rewrite. Summary temporarily receives private data copies; error paths restore its game reference. Other species never inherit this state. |
| Human Ansem | v0.5 field states, v1.0.0 default OFF | Explicit opt-in; preserve walk, bike, surf, fishing, front/back and supplied portrait PNG. No Red patch when unselected. Integration into Crystal's existing selector and portrait/Hall-of-Fame consumers lacks the dependency API. |
| Male/Female rival | v0.3 choice, v0.4 Melony | Independent choice before naming, saved choice, conditional NPC/intro/battle presentation. |
| Wilds follower | v1.0.0 service path, newly narrowed draw adapter | Optional dependency. Tag only exact definitions returned for primary followers; preserve native metadata. Genuine-shiny standard followers retain official image route. Sparkle uses `getScreenOrigin` and frame geometry. No trainer position, party guessing or direction offsets. No origin API means no guessed sparkle. |
| True right-facing follower | v0.2 eight-frame sheet | Use authored right-facing frame in ordinary draws. Specialized clipping/OAM/forced-flip draws delegate to the engine; their right-facing behavior remains unresolved. |
| Kaizo bridge | only v1.0.1 scaling subsystem | One trainer hook composes rivalry and levels; wild hooks copy results/arguments. Independent toggles; upward-only floors and Oak exception retained. All-fainted party produces no dynamic target. No rendering access. |
| Voxel | external only | No Voxel code, dependency, configuration or enable/disable calls. |

## Verification

Lua 5.4 syntax passed using the installed shared library. The supplied smoke harness was adapted to reject duplicate registration/hook ownership and exercise specific regressions. Both Wilds-present/Ansem and Wilds-absent/default runs passed. The report package contains the runnable harness, scripts, chronological diffs and asset inventory. These do not emulate Gen1Recomp, Crystal, Wilds, Voxel or iOS.

See `UNRESOLVED.md` before treating the candidate as release-ready. Use a separate fresh-save diagnostic cart; do not load the old unified/split mod alongside the candidate. Required existing dependencies remain Kaizo and Crystal; Wilds is optional. The ZIP contains no external mod or ROM.
