# Red Earth Irregular — rebuild 0.1.1 audited test candidate

Fresh-save diagnostic candidate reconstructed from local snapshots. Read UNRESOLVED.md before testing. Disable the old unified/split mods. Required existing dependencies: Kaizo and Crystal Animated Sprites with Shiny Visuals. Wilds is optional; Voxel stays external and adjustable. No external mods or ROMs are bundled. No iOS runtime validation has been performed.


## ChatGPT audit patch 0.1.1

Verified against Wilds of Kanto v2.1.9/current source: Wilds shallow-copies follower sprite definitions in `Lifecycle:applyLocalSpriteDef`. The 0.1.0 candidate keyed follower metadata by the pre-copy table identity, so shiny follower sparkle and the custom eight-direction Irregular draw path would not survive into `SpriteRenderer`. 0.1.1 stores the narrow Red Earth metadata on the returned definition itself; Wilds' copy preserves those fields. No battle scale, Voxel, player-coordinate or unrelated-species behavior was changed.
