# Third-party notices

Red Earth: The Irregular and The Philosopher Stones is an unofficial fan modification and is not affiliated with or endorsed by Nintendo, The Pokémon Company, Game Freak, Square Enix, Disney, or other rights holders.

Pokémon names/characters, Melony, and Human Ansem remain the property of their respective rights holders. The bundled project art was supplied for this fan-mod build and is not relicensed by the MIT code license.

Required external mods are downloaded separately from their own authors/repositories and are not redistributed inside this source package.
