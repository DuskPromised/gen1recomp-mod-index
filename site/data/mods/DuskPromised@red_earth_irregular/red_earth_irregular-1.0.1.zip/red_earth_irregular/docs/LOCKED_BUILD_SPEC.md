Here is the **fully consolidated locked build specification** for the Red Earth custom mod, including the Irregular line, shiny behavior, Philosopher’s Stone system, and Human Ansem player skin.

1. **Custom evolution line: Psydren → Vesperis → Solipsdion**
   - Psydren: Psychic/Water.
   - Vesperis: Psychic/Ghost.
   - Solipsdion: Psychic/Dragon by default.
   - Preserve finalized stats, evolution progression, level-up moves, signature moves, lore, and overall role.
   - Solipsdion keeps the canonical **7-wing anatomy: 2 flight wings + 4 hand-wings + 1 crown wing**.
2. **Use the new canonical Pokémon art everywhere**
   - Replace all earlier placeholders/concept sprites.
   - New art must control:
     - battle front
     - battle back
     - follower/overworld
     - party icon
     - menu/summary sprite
     - shiny equivalents
   - No older sprite version should appear anywhere in the game.
3. **Canonical normal/shiny palettes**
   - **Psydren**
     - Normal: green/seafoam
     - Shiny: purple/lilac with cyan ears and pink fins
   - **Vesperis**
     - Normal: white + purple
     - Shiny: grey/silver + crimson/dark wine
   - **Solipsdion**
     - Normal: pearl/lilac/purple + gold
     - Shiny: pearl/white + pink/crimson + gold
4. **Guaranteed shiny Psydren**
   - The gifted Psydren must be a genuine system shiny.
   - It gets:
     - shiny-compatible DVs
     - `mon.shiny = true`
   - It must use our custom shiny artwork rather than the generic shiny recolor system.
5. **Guaranteed shiny Fennekin**
   - The already-existing Fennekin companion gift must be created shiny.
   - It must be actually system-marked shiny, not just visually recolored.
   - Its normal official shiny rendering can be used.
6. **Guaranteed shiny third regional starter**
   - The already-existing third starter chosen through the regional-choice system must also be guaranteed shiny.
   - Same genuine shiny flag/DV behavior as the others.
   - No redesign of the existing region/starter selection flow is needed.
7. **Shiny persistence across evolution**
   - Psydren must remain shiny through:
     - Psydren → Vesperis
     - Vesperis → Solipsdion
   - Fennekin and the regional starter must also remain shiny through their own evolutions.
   - Evolution must preserve the original Pokémon object/state rather than recreate a non-shiny replacement.
8. **Restore shiny battle intro**
   - Every shiny starter must trigger the normal shiny battle send-out effect:
     - sparkle animation
     - shiny SFX
   - Applies to Psydren, Fennekin, regional starter, Vesperis, and Solipsdion.
   - Custom art must not suppress the shiny intro.
9. **Restore shiny follower/overworld effect**
   - Shiny followers must use the shiny sparkle behavior in the overworld.
   - This must work for Psydren, Vesperis, Solipsdion, Fennekin, and the regional starter where follower support applies.
   - Shiny follower state must survive:
     - map changes
     - follower reload
     - menu transitions
     - save/load
     - evolution
10. **Custom shiny art routing**
    - For Psydren/Vesperis/Solipsdion:
      - if the mon is shiny, select our custom shiny PNG
      - do not apply generic shiny palette recoloring on top of it
    - Use true-color rendering where needed.
11. **Distance passive**
    - On entering battle, the first damaging attack that connects deals **25% less damage**.
    - Then Distance breaks.
    - It returns after the Pokémon leaves battle and re-enters.
    - Works on both physical and special damage.
    - It is not:
      - Defense +1
      - Special Defense +1
      - Intimidate
      - a permanent stat debuff on the enemy
12. **Solitary Reign passive**
    - Solipsdion only.
    - Activates when Solipsdion is the **only conscious Pokémon left in the party**.
    - Party slot does not matter.
    - Solipsdion can remain:
      - slot 1
      - lead Pokémon
      - active follower
    - While Reign is active:
      - Special +20%
      - Speed +20%
      - Special cannot be lowered
      - Speed cannot be lowered
    - If another Pokémon becomes conscious again, Reign ends immediately.
13. **Nature: Modest**
    - Solipsdion’s intended Nature is **Modest**.
    - Because Gen 1 does not natively use Natures, implement a small custom Nature layer if practical so it has a real mechanical effect.
    - If implemented mechanically:
      - boost Special
      - reduce Attack
    - Preserve the Nature metadata through evolution/save/load.
14. **Philosopher’s Stone crafting materials**
    - Required components:
      - Salt
      - Sulfur
      - Mercury
      - Aether
15. **Cinnabar Alchemical Crucible**
    - The Philosopher’s Stone is created through a deliberate alchemical sequence:
      - Calcination
      - Dissolution
      - Separation
      - Conjunction
      - Rubedo
    - The Stone should feel earned, not just crafted from a generic menu.
16. **One Philosopher’s Stone per Pokémon**
    - Universal rule.
    - No Pokémon can stack multiple Stones.
    - The Irregular line does not get a second Stone slot.
    - Stone rebinding/removal should only occur through the proper Crucible/system.
17. **First Condition: normal Pokémon**
    - Ordinary Pokémon can use the Philosopher’s Stone normally.
    - They access only the Stone’s **First Condition / standard Transmutation effect**.
    - They cannot unlock the Second Condition.
18. **Irregular-line Stone progression**
    - **Psydren — Resonance**
      - senses/reacts to Philosopher fragments and Stones
      - detects deeper properties but cannot fully access them
    - **Vesperis — Communion**
      - partially interacts with the dormant Stone layer
      - reveals more of the Stone’s hidden nature
    - **Solipsdion — Awakening**
      - fully unlocks the Stone’s Second Condition
19. **Second Condition: Aetheric Transmutation**
    - Solipsdion’s primary type is permanently **Psychic**.
    - Its secondary type dynamically changes according to the dominant environment.
20. **Environment-to-type mapping**
    - Neutral area / ordinary interior → **Psychic/Dragon**
    - Harsh sunlight / volcanic area → **Psychic/Fire**
    - Rain / ocean / water-heavy route → **Psychic/Water**
    - Snow / hail / ice cavern → **Psychic/Ice**
    - Sandstorm / desert → **Psychic/Ground**
    - Cave / rocky underground → **Psychic/Rock**
    - Dense forest / heavy overgrowth → **Psychic/Grass**
21. **Battle weather priority**
    - Active battle weather overrides map/environment attunement.
    - Example:
      - inside cave = Psychic/Rock
      - Rain Dance begins = Psychic/Water
      - Rain Dance ends = return to Psychic/Rock
    - Leaving the cave for a neutral route returns it to Psychic/Dragon.
22. **Seraph’s Verdict follows Aetheric Transmutation**
    - Neutral → Dragon
    - Sun/volcano → Fire
    - Rain/ocean → Water
    - Snow/ice → Ice
    - Sandstorm/desert → Ground
    - Cave/rocky → Rock
    - Forest/overgrowth → Grass
    - Its battle behavior and displayed type should update dynamically.
23. **Dynamic typing in menu/summary**
    - Solipsdion’s current type display must reflect its current environment.
    - Example:
      - Mt. Moon → Psychic/Rock
      - rainy route → Psychic/Water
    - The menu must also continue to show that the Pokémon is shiny.
24. **Stone visual feedback**
    - Do not recolor the entire Pokémon every time its secondary type changes.
    - Keep the canonical normal/shiny artwork intact.
    - Optional later polish:
      - subtle Stone glow
      - aura
      - small attunement indicator
    - This is visual feedback only, not a new transformation sprite set.
25. **Persistence**
    - Save/load must preserve:
      - shiny flag
      - shiny-compatible DVs
      - custom shiny identity
      - Nature
      - Stone binding
      - Stone awakening stage
      - evolution state
      - any custom Pokémon metadata
    - Map transitions and follower reloads must not reset any of this.
26. **Final Pokémon sprite production**
    - Use the transparent RGBA PNG masters already created from the JPEG art.
    - Derive proper game-ready assets for:
      - battle front
      - battle back
      - follower
      - party icon
      - menu/summary
      - normal/shiny variants
    - Preserve crisp pixel art.
    - No photographic smoothing.
    - Use nearest-neighbor scaling where scaling is needed.
    - Stage-specific size should visually communicate growth:
      - Psydren smallest
      - Vesperis larger
      - Solipsdion largest
27. **Follower sprite implementation**
    - Use Gen1Recomp’s variable-size sprite support where appropriate.
    - Properly anchor each sprite so it stands on the correct tile.
    - Avoid clipping, floating, or giant off-screen sprites.
    - Shiny and normal follower sheets must use the same geometry.
28. **Battle sprite scaling**
    - Use per-species/per-image battle scale rather than destroying the source art.
    - Keep Solipsdion visibly larger and more imposing.
    - Preserve grounding and send-out grow behavior.
29. **Human Ansem player skin**
    - Add **white-haired Human Ansem** from the supplied GBA *Kingdom Hearts: Chain of Memories* sheet.
    - Use only the human form.
    - Exclude all Guardian/Heartless/beast forms from the lower half of the sheet.
30. **Ansem must be selectable, not forced**
    - Integrate Human Ansem through the existing **Crystal sprite mod/custom player selection system** already being used in your Red setup.
    - Do not permanently overwrite the default player.
    - Existing selectable characters must remain available.
    - Ansem appears as an additional selectable player option.
31. **Ansem overworld frames**
    - Create/prepare the appropriate:
      - standing down
      - standing up
      - standing left
      - standing right/mirrored left
      - walking frames
    - Use the supplied white-haired human sprite poses as the source.
    - Preserve hard pixel edges.
32. **Ansem special player presentation**
    - Where supported by the selector/system, provide:
      - player battle back
      - Trainer Card/player front
      - Hall of Fame player art
      - intro/front portrait
    - Prevent accidental fallback to the vanilla Red sprite where practical.
33. **Ansem field states**
    - Make sure special field states do not unexpectedly break the skin:
      - fishing
      - Surf
      - bike
      - scripted movement
      - special player poses
    - Reuse the selector’s existing handling wherever possible instead of writing a separate player-rendering system.
34. **Remove Ansem PNG background**
    - The supplied sprite sheet’s teal background must be made transparent.
    - Because it is proper pixel-art PNG, remove the exact background without damaging the sprite edges.
    - No smoothing or redraw.
35. **Compatibility with Red Earth mod stack**
    - Keep compatibility with the existing Red Earth mod collection where possible.
    - Maintain the Shiny Pokémon dependency/integration.
    - Use current Gen1Recomp API 2 hooks rather than invasive renderer hacks unless absolutely necessary.
36. **Final testing: starters**
    - Psydren acquisition = shiny.
    - Fennekin acquisition = shiny.
    - third regional starter acquisition = shiny.
    - All three properly marked shiny by the system.
    - All three show shiny intro effects.
37. **Final testing: custom line**
    - Psydren shiny art correct.
    - Vesperis shiny art correct after evolution.
    - Solipsdion shiny art correct after evolution.
    - No generated recolor overwrites custom shiny art.
    - Battle/front/back/menu/follower all use the correct form.
38. **Final testing: shiny effects**
    - Battle sparkle.
    - Battle SFX.
    - Follower sparkle.
    - Map reload.
    - Save/load.
    - Evolution.
    - Party reorder.
39. **Final testing: passives**
    - Distance only affects first damaging hit after entry.
    - Distance resets properly after leaving/re-entering.
    - Solitary Reign activates only when Solipsdion is the sole conscious Pokémon.
    - Party position has no effect.
    - Reign deactivates correctly if another Pokémon becomes conscious.
40. **Final testing: Philosopher’s Stone**
    - Crafting sequence works.
    - One-Stone-per-Pokémon restriction works.
    - Normal Pokémon only access First Condition.
    - Psydren resonance works.
    - Vesperis partial awakening works.
    - Solipsdion full Second Condition works.
41. **Final testing: Aetheric Transmutation**
    - neutral
    - cave
    - forest
    - desert
    - rain
    - ocean
    - volcano
    - snow/ice
    - battle weather override
    - environment restoration after weather ends
42. **Final testing: Seraph’s Verdict**
    - Correct type in every attunement.
    - Correctly updates when weather changes mid-battle.
    - Correctly returns to map-based type afterward.
43. **Final testing: Human Ansem**
    - Appears in the custom player selector.
    - Correct white-haired human form.
    - No Guardian/Heartless frames.
    - Correct movement facings.
    - Special states do not unexpectedly revert to Red.
    - Existing player skins still work.

That is the **full locked build list** now.

The final visual-production work is:

**Irregular-line game-sized sprites + Human Ansem custom-player assets**, then we can assemble the actual mod around the completed mechanics.