return function(mod)
  local Stats = require("src.pokemon.Stats")
  local Commands = require("src.script.Commands")
  local Assets = require("src.render.Assets")
  local BattleState = require("src.battle.BattleState")
  local SpriteRenderer = require("src.render.SpriteRenderer")
  local PaletteFX = require("src.render.PaletteFX")
  local Game = require("src.core.Game")
  local MapScripts = require("src.script.MapScripts")
  local pokemon = mod.content.pokemon

  local IDS = {
    PSYDREN = "RED_EARTH_PSYDREN",
    VESPERIS = "RED_EARTH_VESPERIS",
    SOLIPSDION = "RED_EARTH_SOLIPSDION",

    SOVEREIGN_RAGE = "RED_EARTH_SOVEREIGN_RAGE",
    AEROBLAST = "RED_EARTH_AEROBLAST",
    SERAPHS_VERDICT = "RED_EARTH_SERAPHS_VERDICT",

    SALT = "RED_EARTH_SALT",
    SULFUR = "RED_EARTH_SULFUR",
    MERCURY = "RED_EARTH_MERCURY",
    AETHER = "RED_EARTH_AETHER",
    PHILOSOPHERS_STONE = "RED_EARTH_PHILOSOPHERS_STONE",
    STONE_EFFECT = "RED_EARTH_BIND_PHILOSOPHERS_STONE",
  }

  local FLAGS = {
    GOT_PSYDREN = "MOD_RED_EARTH_GOT_PSYDREN",
    GOT_FENNEKIN = "MOD_RED_EARTH_GOT_FENNEKIN",
    GOT_GRASS = "MOD_RED_EARTH_GOT_REGIONAL_GRASS",
    RIVAL_FROAKIE = "MOD_RED_EARTH_RIVAL_FROAKIE",

    GOT_SULFUR = "MOD_RED_EARTH_GOT_SULFUR",
    GOT_MERCURY = "MOD_RED_EARTH_GOT_MERCURY",
    GOT_AETHER = "MOD_RED_EARTH_GOT_AETHER",
    GOT_SALT = "MOD_RED_EARTH_GOT_SALT",
  }

  local LINE = {
    [IDS.PSYDREN] = true,
    [IDS.VESPERIS] = true,
    [IDS.SOLIPSDION] = true,
  }

  local function asset(rel)
    return mod.assets:path(rel)
  end

  local function ensureModData(save)
    save.modData = save.modData or {}
    save.modData[mod.id] = save.modData[mod.id] or {}
    return save.modData[mod.id]
  end

  local function flag(save, name)
    return save and save.flags and save.flags[name] == true
  end

  local function setFlag(save, name, value)
    save.flags = save.flags or {}
    save.flags[name] = value ~= false
  end

  local function rivalGender(game)
    game = game or Game
    local save = game and game.save
    local player = save and save.player
    local g = player and player.rivalGender
    if g == "female" or g == "male" then return g end
    local stored = mod.save:get("rival_gender")
    if stored == "female" or stored == "male" then return stored end
    return "male"
  end

  local function setRivalGender(game, value)
    value = (value == "female") and "female" or "male"
    game = game or Game
    if game and game.save then
      game.save.player = game.save.player or {}
      game.save.player.rivalGender = value
    end
    mod.save:set("rival_gender", value)
    return value
  end

  local function isRivalClass(id)
    return id == "OPP_RIVAL1" or id == "OPP_RIVAL2" or id == "OPP_RIVAL3"
  end

  -- Final female-rival assets derived from the user's supplied Melony PNGs.
  -- Stock female art remains only as a defensive fallback if an asset is
  -- manually removed or corrupted.
  local MELONY_FRONT = asset("assets/rival/melony_front.png")
  local MELONY_OVERWORLD = asset("assets/rival/melony_overworld.png")

  local function imageLoads(path)
    if not path then return false end
    local ok, img = pcall(Assets.image, path)
    return ok and img ~= nil
  end

  -- ============================================================
  -- MOVES
  -- ============================================================

  local function registerMove(id, name, moveType, power, accuracy, pp, extra)
    local row = {
      id = id,
      name = name,
      type = moveType,
      power = power,
      accuracy = accuracy,
      pp = pp,
      effect = "NO_ADDITIONAL_EFFECT",
    }
    for k, v in pairs(extra or {}) do row[k] = v end
    mod.content.moves:register(id, row)
  end

  registerMove(IDS.SOVEREIGN_RAGE, "SOVEREIGN RAGE",
    "DRAGON", 90, 100, 10)

  -- Aeroblast is not native to Red. This recreates its basic identity:
  -- Flying, 100 BP, 95 accuracy, high critical-hit ratio.
  registerMove(IDS.AEROBLAST, "AEROBLAST",
    "FLYING", 100, 95, 5, { highCrit = true })

  registerMove(IDS.SERAPHS_VERDICT, "SERAPH'S VERDICT",
    "DRAGON", 110, 100, 5)

  -- ============================================================
  -- SPECIES
  -- Final locked stats/moves from the recovered project.
  -- ============================================================

  local defs = {
    {
      id = IDS.PSYDREN,
      name = "PSYDREN",
      types = { "PSYCHIC", "WATER" },
      baseStats = {
        hp = 55, attack = 40, defense = 65, speed = 45,
        specialAttack = 70, specialDefense = 70,
      },
      catchRate = 45,
      baseExp = 75,
      growthRate = "GROWTH_MEDIUM_SLOW",
      levelMoves = {
        { level = 1, move = "CONFUSION" },
        { level = 1, move = "WITHDRAW" },
        { level = 7, move = "WATER_GUN" },
        { level = 11, move = "HYPNOSIS" },
        { level = 14, move = "BUBBLEBEAM" },
      },
      evolutions = {
        { into = IDS.VESPERIS, method = "EVOLVE_LEVEL", level = 16 },
      },
      spriteFront = asset("assets/pokemon/psydren/normal_front.png"),
      spriteBack = asset("assets/pokemon/psydren/normal_back.png"),
      trueColor = true,
      picSize = 7,
      battleScaleFront = 0.94,
      battleScaleBack = 0.94,
      icon = {
        image = asset("assets/pokemon/psydren/normal_icon.png"),
        width = 16, height = 32, frames = 2,
      },
      cry = "MEW",
    },
    {
      id = IDS.VESPERIS,
      name = "VESPERIS",
      types = { "PSYCHIC", "GHOST" },
      baseStats = {
        hp = 70, attack = 55, defense = 75, speed = 80,
        specialAttack = 95, specialDefense = 95,
      },
      catchRate = 30,
      baseExp = 125,
      growthRate = "GROWTH_MEDIUM_SLOW",
      levelMoves = {
        { level = 16, move = "NIGHT_SHADE" },
        { level = 20, move = "PSYBEAM" },
        { level = 25, move = "CONFUSE_RAY" },
        { level = 29, move = "RECOVER" },
        { level = 33, move = "DREAM_EATER" },
      },
      evolutions = {
        { into = IDS.SOLIPSDION, method = "EVOLVE_LEVEL", level = 36 },
      },
      spriteFront = asset("assets/pokemon/vesperis/normal_front.png"),
      spriteBack = asset("assets/pokemon/vesperis/normal_back.png"),
      trueColor = true,
      picSize = 7,
      battleScaleFront = 1.00,
      battleScaleBack = 1.00,
      icon = {
        image = asset("assets/pokemon/vesperis/normal_icon.png"),
        width = 16, height = 32, frames = 2,
      },
      cry = "HAUNTER",
    },
    {
      id = IDS.SOLIPSDION,
      name = "SOLIPSDION",
      types = { "PSYCHIC", "DRAGON" },
      baseStats = {
        hp = 95, attack = 85, defense = 105, speed = 105,
        specialAttack = 125, specialDefense = 125,
      },
      catchRate = 15,
      baseExp = 220,
      growthRate = "GROWTH_MEDIUM_SLOW",
      levelMoves = {
        { level = 36, move = IDS.SOVEREIGN_RAGE },
        { level = 42, move = "AMNESIA" },
        { level = 49, move = IDS.AEROBLAST },
        { level = 57, move = "HYDRO_PUMP" },
        { level = 65, move = "PSYCHIC" },
        { level = 75, move = IDS.SERAPHS_VERDICT },
      },
      evolutions = {},
      spriteFront = asset("assets/pokemon/solipsdion/normal_front.png"),
      spriteBack = asset("assets/pokemon/solipsdion/normal_back.png"),
      trueColor = true,
      picSize = 7,
      battleScaleFront = 1.08,
      battleScaleBack = 1.05,
      icon = {
        image = asset("assets/pokemon/solipsdion/normal_icon.png"),
        width = 16, height = 32, frames = 2,
      },
      cry = "DRAGONITE",
    },
  }

  -- Register directly against Gen1Recomp's Gen 1 registry.  The earlier
  -- development build used Expanded Species' unreleased Gen 1 conversion;
  -- final v1.0.0 avoids that unpublished dependency and writes the native
  -- Gen 1 record shape instead.
  local maxDex = 0
  for _, def in pokemon:each() do
    maxDex = math.max(maxDex, tonumber(def.dex) or 0)
  end

  local function nativeRecord(source, dex)
    local level1, learnset, evolutions = {}, {}, {}
    for _, row in ipairs(source.levelMoves or {}) do
      local lv = tonumber(row.level) or 1
      if lv <= 1 then level1[#level1 + 1] = row.move end
      learnset[#learnset + 1] = { level = lv, move = row.move }
    end
    for _, evo in ipairs(source.evolutions or {}) do
      if evo.method == "EVOLVE_LEVEL" then
        evolutions[#evolutions + 1] = {
          method = "LEVEL", level = evo.level, species = evo.into,
        }
      elseif evo.method == "EVOLVE_ITEM" then
        evolutions[#evolutions + 1] = {
          method = "ITEM", item = evo.item, species = evo.into,
        }
      elseif evo.method == "EVOLVE_TRADE" then
        evolutions[#evolutions + 1] = {
          method = "TRADE", species = evo.into,
        }
      end
    end
    local sp = source.baseStats or {}
    return {
      id = source.id, name = source.name, dex = dex,
      types = source.types,
      baseStats = {
        hp = sp.hp, attack = sp.attack, defense = sp.defense, speed = sp.speed,
        special = sp.special or math.max(sp.specialAttack or 1, sp.specialDefense or 1),
      },
      catchRate = source.catchRate or 45,
      baseExp = source.baseExp or 100,
      growthRate = ({
        GROWTH_MEDIUM_SLOW = "MEDIUM_SLOW",
        GROWTH_MEDIUM_FAST = "MEDIUM_FAST",
        GROWTH_FAST = "FAST",
        GROWTH_SLOW = "SLOW",
      })[source.growthRate] or source.growthRate or "MEDIUM_FAST",
      level1Moves = level1,
      learnset = learnset,
      evolutions = evolutions,
      spriteFront = source.spriteFront, spriteBack = source.spriteBack,
      frontSize = source.picSize or 7, trueColor = source.trueColor == true,
      battleScaleFront = source.battleScaleFront,
      battleScaleBack = source.battleScaleBack,
      icon = source.icon, cry = source.cry, dexEntry = source.dexEntry,
    }
  end

  for i, source in ipairs(defs) do
    pokemon:register(source.id, nativeRecord(source, maxDex + i))
  end
  if mod.content.constants then
    mod.content.constants:patch("dexSize", maxDex + #defs)
  end

  -- ============================================================
  -- GENUINE SHINY STATE + MODEST NATURE
  -- ============================================================

  local function isShiny(mon)
    if not mon then return false end
    return mon.shiny == true or (Stats.isShiny and Stats.isShiny(mon.dvs))
  end

  local function shinyDVs()
    local dvs = { attack = 15, defense = 10, speed = 10, special = 10 }
    -- Gen-2 shiny-compatible HP DV is derived from the low bits.
    dvs.hp = (dvs.attack % 2) * 8
      + (dvs.defense % 2) * 4
      + (dvs.speed % 2) * 2
      + (dvs.special % 2)
    return dvs
  end

  local function applyModest(mon, game)
    if not mon or mon.redEarthNature ~= "MODEST" then return end
    game = game or Game
    local data = game and game.data
    local def = data and data.pokemon and data.pokemon[mon.species]
    if not def then return end

    local raw = Stats.calc(def, mon.level or 1, mon.dvs, mon.statExp)
    -- Modern Modest: +10% Special / -10% Attack. HP/Def/Speed remain native.
    raw.attack = math.max(1, math.floor(raw.attack * 0.90))
    raw.special = math.max(1, math.floor(raw.special * 1.10))
    mon.stats = raw
    if mon.hp and mon.hp > raw.hp then mon.hp = raw.hp end
  end

  local function markGuaranteedShiny(mon, game, opts)
    if not mon then return nil end
    opts = opts or {}
    game = game or Game
    mon.dvs = shinyDVs()
    mon.shiny = true
    mon.redEarthGuaranteedShiny = true

    if opts.mainLine or LINE[mon.species] then
      mon.redEarthNature = mon.redEarthNature or "MODEST"
      if mon.species == IDS.PSYDREN then
        mon.redEarthStoneStage = mon.redEarthStoneStage or "RESONANCE"
      elseif mon.species == IDS.VESPERIS then
        mon.redEarthStoneStage = "COMMUNION"
      elseif mon.species == IDS.SOLIPSDION then
        mon.redEarthStoneStage = "AWAKENING"
      end
      applyModest(mon, game)
    else
      -- Fennekin and the third regional starter are genuine shinies too.
      -- Recalculate immediately after replacing their DVs so their level-5
      -- stats do not remain based on the pre-gift random DVs until level-up.
      local def = game and game.data and game.data.pokemon
        and game.data.pokemon[mon.species]
      if def and def.baseStats then
        mon.stats = Stats.calc(def, mon.level or 1, mon.dvs, mon.statExp)
        if mon.stats and mon.stats.hp then mon.hp = mon.stats.hp end
      end
    end
    return mon
  end

  local function snapshotMons(save)
    local seen = {}
    local function add(list)
      for _, mon in ipairs(list or {}) do
        if type(mon) == "table" then seen[mon] = true end
      end
    end
    add(save and save.party)
    for _, box in ipairs(save and save.boxes or {}) do add(box) end
    add(save and save.box)
    return seen
  end

  local function findNewMon(save, seen)
    local function scan(list)
      for _, mon in ipairs(list or {}) do
        if type(mon) == "table" and not seen[mon] then return mon end
      end
    end
    local mon = scan(save and save.party)
    if mon then return mon end
    for _, box in ipairs(save and save.boxes or {}) do
      mon = scan(box)
      if mon then return mon end
    end
    return scan(save and save.box)
  end

  local function giveGuaranteedShiny(ctx, species, level, opts)
    opts = opts or {}
    local game = (ctx and ctx.game) or Game
    local save = (ctx and ctx.save) or (game and game.save)
    if not (ctx and game and save and game.data and game.data.pokemon
        and game.data.pokemon[species]) then
      return { ok = false, error = "species unavailable" }
    end
    local seen = snapshotMons(save)
    -- Run the engine's native GivePokemon path so party-full / box-full, OT,
    -- Pokédex, nickname and box text stay correct.
    Commands.give_pokemon(ctx, species, tonumber(level) or 5, false, false)
    if not ctx.lastCheck then return { ok = false, error = "party and box full" } end
    local mon = findNewMon(save, seen)
    if not mon then return { ok = false, error = "gift created no detectable mon" } end
    markGuaranteedShiny(mon, game, opts)
    return { ok = true, mon = mon, addedToParty = ctx.addedToParty, boxNum = ctx.boxNum }
  end

  mod.events:on("pokemon.evolved", function(ev)
    local mon = ev and ev.mon
    if not mon then return end

    -- Native evolution mutates the existing mon, so custom fields and DVs
    -- already survive. Reassert the explicit shiny flag for mods/UI that
    -- inspect mon.shiny rather than the DV test.
    if mon.redEarthGuaranteedShiny or isShiny(mon) and LINE[mon.species] then
      mon.shiny = true
    end

    if LINE[mon.species] then
      mon.redEarthNature = mon.redEarthNature or "MODEST"
      if mon.species == IDS.PSYDREN then
        mon.redEarthStoneStage = "RESONANCE"
      elseif mon.species == IDS.VESPERIS then
        mon.redEarthStoneStage = "COMMUNION"
      elseif mon.species == IDS.SOLIPSDION then
        mon.redEarthStoneStage = "AWAKENING"
      end
      applyModest(mon, Game)
    end
  end)

  mod.events:on("pokemon.level_up", function(ev)
    local mon = ev and ev.mon
    if mon and mon.redEarthNature == "MODEST" then applyModest(mon, Game) end
  end)

  -- ============================================================
  -- CANONICAL HAND-AUTHORED SHINY ART
  -- ============================================================

  local ART = {
    [IDS.PSYDREN] = {
      normalFront = asset("assets/pokemon/psydren/normal_front.png"),
      normalBack = asset("assets/pokemon/psydren/normal_back.png"),
      normalMenu = asset("assets/pokemon/psydren/normal_menu.png"),
      normalIcon = asset("assets/pokemon/psydren/normal_icon.png"),
      normalFollower = asset("assets/pokemon/psydren/normal_follower.png"),
      normalFollower8 = asset("assets/pokemon/psydren/normal_follower_8dir.png"),
      shinyFront = asset("assets/pokemon/psydren/shiny_front.png"),
      shinyBack = asset("assets/pokemon/psydren/shiny_back.png"),
      shinyMenu = asset("assets/pokemon/psydren/shiny_menu.png"),
      shinyIcon = asset("assets/pokemon/psydren/shiny_icon.png"),
      shinyFollower = asset("assets/pokemon/psydren/shiny_follower.png"),
      shinyFollower8 = asset("assets/pokemon/psydren/shiny_follower_8dir.png"),
    },
    [IDS.VESPERIS] = {
      normalFront = asset("assets/pokemon/vesperis/normal_front.png"),
      normalBack = asset("assets/pokemon/vesperis/normal_back.png"),
      normalMenu = asset("assets/pokemon/vesperis/normal_menu.png"),
      normalIcon = asset("assets/pokemon/vesperis/normal_icon.png"),
      normalFollower = asset("assets/pokemon/vesperis/normal_follower.png"),
      normalFollower8 = asset("assets/pokemon/vesperis/normal_follower_8dir.png"),
      shinyFront = asset("assets/pokemon/vesperis/shiny_front.png"),
      shinyBack = asset("assets/pokemon/vesperis/shiny_back.png"),
      shinyMenu = asset("assets/pokemon/vesperis/shiny_menu.png"),
      shinyIcon = asset("assets/pokemon/vesperis/shiny_icon.png"),
      shinyFollower = asset("assets/pokemon/vesperis/shiny_follower.png"),
      shinyFollower8 = asset("assets/pokemon/vesperis/shiny_follower_8dir.png"),
    },
    [IDS.SOLIPSDION] = {
      normalFront = asset("assets/pokemon/solipsdion/normal_front.png"),
      normalBack = asset("assets/pokemon/solipsdion/normal_back.png"),
      normalMenu = asset("assets/pokemon/solipsdion/normal_menu.png"),
      normalIcon = asset("assets/pokemon/solipsdion/normal_icon.png"),
      normalFollower = asset("assets/pokemon/solipsdion/normal_follower.png"),
      normalFollower8 = asset("assets/pokemon/solipsdion/normal_follower_8dir.png"),
      shinyFront = asset("assets/pokemon/solipsdion/shiny_front.png"),
      shinyBack = asset("assets/pokemon/solipsdion/shiny_back.png"),
      shinyMenu = asset("assets/pokemon/solipsdion/shiny_menu.png"),
      shinyIcon = asset("assets/pokemon/solipsdion/shiny_icon.png"),
      shinyFollower = asset("assets/pokemon/solipsdion/shiny_follower.png"),
      shinyFollower8 = asset("assets/pokemon/solipsdion/shiny_follower_8dir.png"),
    },
  }

  local function artPath(mon, species, kind, side)
    species = species or (mon and mon.species)
    local art = species and ART[species]
    if not art then return nil end
    local shiny = mon and isShiny(mon) or false
    if kind == "summary" or kind == "dex" or kind == "menu" or kind == "box" then
      return shiny and art.shinyMenu or art.normalMenu
    end
    if side == "back" then return shiny and art.shinyBack or art.normalBack end
    return shiny and art.shinyFront or art.normalFront
  end

  mod.hooks:wrap("pokemon.sprite", function(next, path, ctx)
    ctx = ctx or {}
    local chosen = artPath(ctx.mon, ctx.species, ctx.kind, ctx.side)
    if chosen then
      ctx.trueColor = true
      return chosen
    end
    return next(path, ctx)
  end)

  mod.hooks:wrap("pokemon.icon", function(next, path, ctx)
    ctx = ctx or {}
    local mon = ctx.mon
    local species = ctx.species or (mon and mon.species)
    local art = species and ART[species]
    if art then
      ctx.trueColor = true
      return mon and isShiny(mon) and art.shinyIcon or art.normalIcon
    end
    return next(path, ctx)
  end)


  -- ============================================================
  -- STARTER SEQUENCE
  --
  -- 1) Psydren
  -- 2) Fennekin companion; Blue counter-picks Froakie
  -- 3) remaining ball -> choose REGION again -> that region's Grass starter
  -- ============================================================

  local REGIONAL_GRASS = {
    { region = "KANTO",  species = "BULBASAUR" },
    { region = "JOHTO",  species = "CHIKORITA" },
    { region = "HOENN",  species = "TREECKO" },
    { region = "SINNOH", species = "TURTWIG" },
    { region = "UNOVA",  species = "SNIVY" },
    { region = "KALOS",  species = "CHESPIN" },
    { region = "ALOLA",  species = "ROWLET" },
  }

  local function speciesExists(game, species)
    return game and game.data and game.data.pokemon
       and game.data.pokemon[species] ~= nil
  end

  mod.content.commands:register("red_earth:give_shiny", {
    foreground = true,
    fn = function(ctx, species, level, isMainLine)
      local result = giveGuaranteedShiny(ctx, species, tonumber(level) or 5, {
        mainLine = isMainLine == true,
      })
      ctx.lastCheck = result and result.ok == true
      ctx.lastChoice = result
      if not ctx.lastCheck then
        mod.log:warn("Could not give shiny %s: %s",
          tostring(species), tostring(result and result.error or "unknown error"))
      end
    end,
  })

  mod.content.commands:register("red_earth:regional_grass_choice", {
    foreground = true,
    blocking = true,
    fn = function(ctx)
      local Menu = require("src.ui.Menu")
      local runner = ctx.runner
      local choices = {}

      for _, row in ipairs(REGIONAL_GRASS) do
        if speciesExists(ctx.game, row.species) then
          choices[#choices + 1] = row
        end
      end

      if #choices == 0 then
        ctx.lastCheck = false
        ctx.lastChoice = nil
        mod.log:warn("No regional Grass starter species are installed")
        return
      end

      local items = {}
      for i, row in ipairs(choices) do
        items[i] = {
          label = row.region,
          onSelect = function()
            local result = giveGuaranteedShiny(ctx, row.species, 5, {})
            if result and result.ok then
              local md = ensureModData(ctx.save)
              md.thirdStarterRegion = row.region
              md.thirdStarterSpecies = row.species
              ctx.lastCheck = true
              ctx.lastChoice = {
                index = i, label = row.region,
                region = row.region, species = row.species,
                result = result,
              }
            else
              ctx.lastCheck = false
              ctx.lastChoice = result
            end
            ctx.game.stack:pop()
            runner:resume()
          end,
        }
      end

      items[#items + 1] = {
        label = "CANCEL",
        onSelect = function()
          ctx.lastCheck = false
          ctx.lastChoice = nil
          ctx.game.stack:pop()
          runner:resume()
        end,
      }

      local menu = Menu.new(ctx.game, items, {
        onCancel = function()
          ctx.lastCheck = false
          ctx.lastChoice = nil
          ctx.game.stack:pop()
          runner:resume()
        end,
      })
      ctx.game.stack:push(menu)
      runner:yield()
    end,
  })

  mod.content.commands:register("red_earth:champion_gate", {
    fn = function(ctx)
      local hof = ctx.save and ctx.save.hallOfFame
      local champion = false
      if type(hof) == "table" then
        if type(hof.count) == "number" then
          champion = hof.count > 0
        elseif #hof > 0 then
          champion = true
        end
      end
      ctx.lastCheck = champion
    end,
  })

  -- Base lab scientist fallback used by the Crucible override below.
  mod.content.commands:register("red_earth:base_cinnabar_scientist", {
    foreground = true,
    blocking = true,
    fn = function(ctx)
      local base = MapScripts.baseTalk(
        "CINNABAR_LAB_METRONOME_ROOM",
        "TEXT_CINNABARLABMETRONOMEROOM_SCIENTIST1")
      if not base then return end
      local runner = ctx.runner
      if type(base) == "function" then
        base(ctx.game, ctx.overworld, ctx.npc, function() runner:resume() end)
        runner:yield()
      else
        runner:run(base, ctx)
      end
    end,
  })

  local function psydrenBall()
    return {
      { "check_flag", FLAGS.GOT_PSYDREN },
      { "jump_if_true", "already" },
      { "check_flag", "EVENT_FOLLOWED_OAK_INTO_LAB" },
      { "jump_if_false", "not_yet" },

      { "show_text",
        "A strange POKéMON\nwatches you from\ninside the ball." },
      { "show_text", "Take PSYDREN?" },
      { "choice", { "YES", "NO" } },
      { "jump_if_false", "end" },

      { "red_earth:give_shiny", IDS.PSYDREN, 5, true },
      { "jump_if_false", "failed" },
      { "set_flag", "EVENT_GOT_STARTER" },
      { "set_flag", FLAGS.GOT_PSYDREN },
      { "hide_object", "OAKS_LAB", "OAKSLAB_CHARMANDER_POKE_BALL" },
      { "text_sound", "Get_Key_Item" },
      { "show_text", "{PLAYER} received\nPSYDREN!" },
      { "show_text",
        "OAK: Good. Now take\na companion from\nthe next ball." },
      { "jump", "end" },

      { "label", "already" },
      { "show_text", "The ball is empty." },
      { "jump", "end" },

      { "label", "not_yet" },
      { "show_text", "_OaksLabThoseArePokeBallsText" },
      { "jump", "end" },

      { "label", "failed" },
      { "show_text", "Something prevented\nthe gift." },
    }
  end

  local function fennekinBall()
    return {
      { "check_flag", FLAGS.GOT_PSYDREN },
      { "jump_if_false", "sealed" },
      { "check_flag", FLAGS.GOT_FENNEKIN },
      { "jump_if_true", "already" },

      { "show_text",
        "A warm presence\nstirs inside." },
      { "show_text", "Take FENNEKIN as\nyour companion?" },
      { "choice", { "YES", "NO" } },
      { "jump_if_false", "end" },

      { "red_earth:give_shiny", "FENNEKIN", 5, false },
      { "jump_if_false", "missing" },
      { "set_flag", FLAGS.GOT_FENNEKIN },
      -- Keep the vanilla rival positioning logic coherent: the center ball
      -- corresponds to the old Squirtle slot.
      { "set_flag", "EVENT_CHOSE_SQUIRTLE" },
      { "hide_object", "OAKS_LAB", "OAKSLAB_SQUIRTLE_POKE_BALL" },
      { "text_sound", "Get_Key_Item" },
      { "show_text", "{PLAYER} received\nFENNEKIN!" },
      { "face_object", 1, "down" },
      { "show_text",
        "BLUE: Fine! Then I'll\ntake FROAKIE!" },
      { "set_flag", FLAGS.RIVAL_FROAKIE },
      { "show_text",
        "OAK: The last ball is\noptional. It responds\nto the REGION you name." },
      { "jump", "end" },

      { "label", "sealed" },
      { "show_text",
        "The ball will not\nopen before PSYDREN\nchooses you." },
      { "jump", "end" },

      { "label", "already" },
      { "show_text", "The ball is empty." },
      { "jump", "end" },

      { "label", "missing" },
      { "show_text",
        "FENNEKIN is not\navailable in the\ncurrent species pack." },
    }
  end

  local function regionalGrassBall()
    return {
      { "check_flag", FLAGS.GOT_FENNEKIN },
      { "jump_if_false", "sealed" },
      { "check_flag", FLAGS.GOT_GRASS },
      { "jump_if_true", "already" },

      { "show_text",
        "The final ball asks\nfor a REGION." },
      { "show_text",
        "Its choice is fixed\nto that region's\nGRASS starter." },
      { "red_earth:regional_grass_choice" },
      { "jump_if_false", "end" },
      { "set_flag", FLAGS.GOT_GRASS },
      { "hide_object", "OAKS_LAB", "OAKSLAB_BULBASAUR_POKE_BALL" },
      { "text_sound", "Get_Key_Item" },
      { "show_text",
        "The regional GRASS\nstarter joined you!" },
      { "jump", "end" },

      { "label", "sealed" },
      { "show_text",
        "OAK: Choose your\nFENNEKIN companion\nfirst." },
      { "jump", "end" },

      { "label", "already" },
      { "show_text", "The ball is empty." },
    }
  end

  mod.content.map_scripts:register("OAKS_LAB", {
    priority = 2000,
    talk = {
      TEXT_OAKSLAB_CHARMANDER_POKE_BALL = psydrenBall(),
      TEXT_OAKSLAB_SQUIRTLE_POKE_BALL = fennekinBall(),
      TEXT_OAKSLAB_BULBASAUR_POKE_BALL = regionalGrassBall(),
    },

    -- Psydren makes EVENT_GOT_STARTER true. Until Fennekin is also taken,
    -- consume the exit step so the vanilla rival battle cannot fire early.
    onStep = function(game, ow, x, y)
      local flags = game.save and game.save.flags or {}
      if flags[FLAGS.GOT_PSYDREN]
         and not flags[FLAGS.GOT_FENNEKIN]
         and not flags.EVENT_BATTLED_RIVAL_IN_OAKS_LAB
         and y >= 6 then
        ow.runner:run({
          { "show_text",
            "OAK: Not yet.\nChoose your companion\nbefore you leave." },
          { "move_player", "up", 1 },
        }, {})
        return true
      end
      return false
    end,
  })

  -- Blue counter-picks the Froakie line and keeps it for every rival phase.
  -- Kaizo can compose its base rival starter from any regional family, so
  -- identify the starter slot by evolutionary stage rather than assuming a
  -- water-family placeholder. The rest of every authored roster is preserved.
  local RIVAL_STARTER_STAGE = {
    BULBASAUR=1, IVYSAUR=2, VENUSAUR=3,
    CHARMANDER=1, CHARMELEON=2, CHARIZARD=3,
    SQUIRTLE=1, WARTORTLE=2, BLASTOISE=3,
    CHIKORITA=1, BAYLEEF=2, MEGANIUM=3,
    CYNDAQUIL=1, QUILAVA=2, TYPHLOSION=3,
    TOTODILE=1, CROCONAW=2, FERALIGATR=3,
    TREECKO=1, GROVYLE=2, SCEPTILE=3,
    TORCHIC=1, COMBUSKEN=2, BLAZIKEN=3,
    MUDKIP=1, MARSHTOMP=2, SWAMPERT=3,
    TURTWIG=1, GROTLE=2, TORTERRA=3,
    CHIMCHAR=1, MONFERNO=2, INFERNAPE=3,
    PIPLUP=1, PRINPLUP=2, EMPOLEON=3,
    SNIVY=1, SERVINE=2, SERPERIOR=3,
    TEPIG=1, PIGNITE=2, EMBOAR=3,
    OSHAWOTT=1, DEWOTT=2, SAMUROTT=3,
    CHESPIN=1, QUILLADIN=2, CHESNAUGHT=3,
    FENNEKIN=1, BRAIXEN=2, DELPHOX=3,
    FROAKIE=1, FROGADIER=2, GRENINJA=3,
    ROWLET=1, DARTRIX=2, DECIDUEYE=3,
    LITTEN=1, TORRACAT=2, INCINEROAR=3,
    POPPLIO=1, BRIONNE=2, PRIMARINA=3,
  }
  local FROAKIE_LINE = { "FROAKIE", "FROGADIER", "GRENINJA" }

  -- ============================================================
  -- KAIZO DYNAMIC DIFFICULTY BRIDGE
  -- Restores the authored Red Earth scaling layer while leaving Allgen Kaizo
  -- authoritative for roster composition, movesets, AI, bosses and floors.
  -- Both switches default ON on a fresh install.
  -- ============================================================

  local function optionEnabled(key, fallback)
    local ok, value = pcall(mod.options.get, mod.options, key)
    if ok and value ~= nil then return value end
    return fallback
  end

  local function scaleHash(text)
    local h = 0
    text = tostring(text or "")
    for i = 1, #text do
      h = (h * 33 + text:byte(i)) % 2147483647
    end
    return h
  end

  local function strongestHealthy(game)
    local best, fallback = 0, 0
    for _, mon in ipairs(game and game.save and game.save.party or {}) do
      local lv = tonumber(mon.level) or 0
      if lv > fallback then fallback = lv end
      if (tonumber(mon.hp) or 0) > 0 and lv > best then best = lv end
    end
    if best <= 0 then best = fallback end
    return math.max(0, math.min(100, best))
  end

  local function dynamicWildTarget(game, species, mapId)
    local top = strongestHealthy(game)
    if top <= 0 then return nil end
    local offsets = { -2, -1, 0, 1 }
    local key = tostring(mapId or "") .. "|" .. tostring(species or "") .. "|" .. tostring(top)
    local off = offsets[(scaleHash(key) % #offsets) + 1]
    return math.max(1, math.min(100, top + off))
  end

  -- Let Kaizo / encounter mods roll first, then raise only when the dynamic
  -- target is higher. A stronger authored encounter is never scaled down.
  mod.hooks:wrap("encounter.species", function(next, enc, ctx)
    local rolled = next(enc, ctx)
    if not optionEnabled("dynamic_wilds", true) or type(rolled) ~= "table" then
      return rolled
    end
    local game = Game
    local target = dynamicWildTarget(game, rolled.species, ctx and ctx.mapId)
    if not target then return rolled end
    local out = {}
    for k, v in pairs(rolled) do out[k] = v end
    out.level = math.max(tonumber(rolled.level) or 1, target)
    return out
  end)

  -- Wilds of Kanto and other authored scripts can start wild battles directly.
  -- Rewrite only a copied command argument list so map scripts stay immutable.
  mod.hooks:wrap("script.command", function(next, ctx, name, args, ...)
    if name == "start_battle" and optionEnabled("dynamic_wilds", true)
       and type(args) == "table" and args[1] == "wild" then
      local game = (ctx and ctx.game) or Game
      local mapId = ctx and ctx.overworld and ctx.overworld.map and ctx.overworld.map.id
      local target = dynamicWildTarget(game, args[2], mapId)
      if target then
        local rewritten = {}
        for i, v in ipairs(args) do rewritten[i] = v end
        rewritten[3] = math.max(tonumber(args[3]) or 1, target)
        return next(ctx, name, rewritten, ...)
      end
    end
    return next(ctx, name, args, ...)
  end)

  mod.hooks:wrap("trainer.party", function(next, trainerClass, partyIndex, party)
    local base = next(trainerClass, partyIndex, party)
    local save = Game and Game.save
    if type(base) ~= "table" or #base == 0 then return base end

    -- Preserve every authored Kaizo slot/moveset/AI choice. Only the rival's
    -- starter species line is rewritten after Fennekin, and then levels are
    -- raised upward when the dynamic difficulty layer calls for it.
    local out = base
    if isRivalClass(trainerClass) and save and flag(save, FLAGS.RIVAL_FROAKIE)
       and speciesExists(Game, "FROAKIE") then
      local rewritten = {}
      for i, member in ipairs(out) do
        local copy = {}
        for k, v in pairs(member) do copy[k] = v end
        local stage = RIVAL_STARTER_STAGE[copy.species]
        local replacement = stage and FROAKIE_LINE[stage]
        if replacement and speciesExists(Game, replacement) then
          copy.species = replacement
          -- Never carry another starter family's competitive moves across.
          -- The Froakie-line learnset rebuilds the replacement naturally.
          copy.moves = nil
        end
        rewritten[i] = copy
      end
      out = rewritten
    end

    if not optionEnabled("dynamic_trainers", true) then return out end
    local top = strongestHealthy(Game)
    if top <= 0 then return out end

    -- Preserve the authored Lv5 Oak-lab rival battle. Dynamic trainer scaling
    -- begins immediately after that scripted tutorial battle.
    local flags = save and save.flags or {}
    local mapId = Game and Game.overworld and Game.overworld.map and Game.overworld.map.id
    if tostring(trainerClass):find("RIVAL1", 1, true)
       and mapId == "OAKS_LAB" and not flags.EVENT_BATTLED_RIVAL_IN_OAKS_LAB then
      return out
    end

    local scaled = {}
    local n = #out
    for i, member in ipairs(out) do
      local copy = {}
      for k, v in pairs(member) do copy[k] = v end
      local plus
      if n == 1 then
        plus = 2
      else
        plus = math.floor((((i - 1) * 2) / (n - 1)) + 0.5)
      end
      local target = math.min(100, top + plus)
      copy.level = math.max(tonumber(member.level) or 1, target)
      scaled[i] = copy
    end
    return scaled
  end)

  -- ============================================================
  -- DISTANCE
  -- First damaging attack after entry is reduced 25%, then Distance breaks.
  -- ============================================================

  local distanceReady = setmetatable({}, { __mode = "k" })
  local activeBattle = nil

  -- First Condition — Transmutation (ordinary Pokémon):
  -- once per battle, when a Stone-bound Pokémon falls to <= 1/3 HP,
  -- it restores 25% max HP. This is intentionally restorative rather than
  -- another type-changing mechanic, leaving Aetheric Transmutation unique.
  local stoneRenewalUsed = setmetatable({}, { __mode = "k" })

  local function armDistanceBattler(battler)
    local mon = battler and battler.mon
    if mon and LINE[mon.species] then distanceReady[mon] = true end
  end

  mod.events:on("battle.started", function(ev)
    local b = ev and ev.battle
    if not b then return end
    activeBattle = b
    armDistanceBattler(b.player)
    armDistanceBattler(b.enemy)
    for _, battler in ipairs({ b.player, b.enemy }) do
      if battler and battler.mon then
        stoneRenewalUsed[battler.mon] = nil
      end
    end
  end)

  mod.events:on("battle.battler_switched", function(ev)
    armDistanceBattler(ev and ev.battler)
  end)

  mod.events:on("battle.ended", function(ev)
    if not ev or not ev.battle or activeBattle == ev.battle then
      activeBattle = nil
    end
  end)

  -- ============================================================
  -- SOLITARY REIGN
  -- Sole conscious party member; +20% Special and Speed.
  -- Negative Special/Speed stages are mechanically ignored while active.
  -- ============================================================

  local function partyForBattler(battle, battler)
    if not battle or not battler then return nil end
    if battler.isPlayer or battler == battle.player then
      return battle.playerParty or (battle.playerPartyView and battle:playerPartyView())
    end
    return battle.enemyParty
  end

  local function consciousCount(party)
    local n = 0
    for _, mon in ipairs(party or {}) do
      if mon and (mon.hp or 0) > 0 then n = n + 1 end
    end
    return n
  end

  local function reignActive(battle, battler)
    local mon = battler and battler.mon
    return mon ~= nil
       and mon.species == IDS.SOLIPSDION
       and (mon.hp or 0) > 0
       and consciousCount(partyForBattler(battle, battler)) == 1
  end

  local function shallowCopy(t)
    local c = {}
    for k, v in pairs(t or {}) do c[k] = v end
    return c
  end

  local SPECIAL_TYPES = {
    FIRE = true, WATER = true, ELECTRIC = true, GRASS = true,
    ICE = true, PSYCHIC = true, DRAGON = true,
  }

  local function moveIsSpecial(move)
    if not move then return false end
    if move.category then return move.category == "special" end
    return SPECIAL_TYPES[move.type] == true
  end

  -- ============================================================
  -- PHILOSOPHER'S STONE + SECOND CONDITION FOUNDATION
  -- ============================================================

  local function registerMaterial(id, name)
    mod.content.items:register(id, {
      id = id, name = name, price = 0, tossable = false,
    })
  end

  registerMaterial(IDS.SALT, "ALCHEMICAL SALT")
  registerMaterial(IDS.SULFUR, "ALCHEMICAL SULFUR")
  registerMaterial(IDS.MERCURY, "ALCHEMICAL MERCURY")
  registerMaterial(IDS.AETHER, "AETHER")

  local function forEachOwnedMon(save, fn)
    for _, mon in ipairs(save and save.party or {}) do fn(mon) end
    for _, box in ipairs(save and save.boxes or {}) do
      for _, mon in ipairs(box or {}) do fn(mon) end
    end
    for _, mon in ipairs(save and save.box or {}) do fn(mon) end
    if save and save.daycare and save.daycare.mon then fn(save.daycare.mon) end
  end

  local function findBoundStoneMon(save, except)
    local found
    forEachOwnedMon(save, function(mon)
      if not found and mon ~= except and mon.redEarthPhilosophersStone == true then
        found = mon
      end
    end)
    return found
  end

  mod.content.item_effects:register(IDS.STONE_EFFECT, {
    needsTarget = true,
    battle = false,
    field = true,
    use = function(ctx)
      local mon = ctx.target
      if not mon then
        return "failed", { "Choose a POKéMON." }
      end
      if mon.redEarthPhilosophersStone then
        return "failed", { "That POKéMON is already\nbound to the Stone." }
      end
      local other = findBoundStoneMon(ctx.save, mon)
      if other then
        return "failed", { "The Stone is already\nbound elsewhere.\nUse the CRUCIBLE." }
      end

      mon.redEarthPhilosophersStone = true
      mon.redEarthStoneCondition = "FIRST"
      if mon.species == IDS.PSYDREN then
        mon.redEarthStoneStage = "RESONANCE"
      elseif mon.species == IDS.VESPERIS then
        mon.redEarthStoneStage = "COMMUNION"
      elseif mon.species == IDS.SOLIPSDION then
        mon.redEarthStoneStage = "AWAKENING"
        mon.redEarthStoneCondition = "SECOND"
      end

      local def = ctx.data.pokemon[mon.species]
      local name = mon.nickname or (def and def.name) or "POKéMON"
      return "consumed", {
        "The PHILOSOPHER'S\nSTONE bound to\n" .. name .. "!"
      }
    end,
  })

  mod.content.items:register(IDS.PHILOSOPHERS_STONE, {
    id = IDS.PHILOSOPHERS_STONE,
    name = "PHILOSOPHER STONE",
    price = 0,
    tossable = false,
    needsTarget = true,
    effect = IDS.STONE_EFFECT,
  })

  local function hasItem(save, id)
    local inv = save and save.inventory
    if type(inv) ~= "table" then return false end
    if type(inv[id]) == "number" then return inv[id] > 0 end
    -- Some save shapes use rows rather than a keyed map.
    for _, row in ipairs(inv) do
      if row and (row.id == id or row.item == id) and (row.count or row.quantity or 1) > 0 then
        return true
      end
    end
    return false
  end


  -- ------------------------------------------------------------
  -- ALCHEMICAL MATERIAL ACQUISITION
  --
  -- SULFUR  = fire / will      -> Blaine
  -- MERCURY = change / intellect -> Silph Co. Master Ball milestone
  -- AETHER  = spirit           -> Mr. Fuji rescue
  -- SALT    = body / stability -> final Giovanni victory
  --
  -- These are story rewards, not random drops. They backfill on an older
  -- save too, so installing the mod after a milestone does not soft-lock
  -- Philosopher's Stone crafting.
  -- ------------------------------------------------------------

  local Bag = require("src.inventory.Bag")

  mod.content.commands:register("red_earth:has_bound_stone", {
    fn = function(ctx)
      ctx.lastCheck = findBoundStoneMon(ctx.save) ~= nil
    end,
  })

  mod.content.commands:register("red_earth:reclaim_stone", {
    foreground = true,
    fn = function(ctx)
      local mon = findBoundStoneMon(ctx.save)
      if not mon then ctx.lastCheck = false return end
      if not Bag.add(ctx.save, IDS.PHILOSOPHERS_STONE, 1, ctx.game.data) then
        ctx.lastCheck = false
        return
      end
      mon.redEarthPhilosophersStone = nil
      mon.redEarthStoneCondition = nil
      -- Resonance / Communion / Awakening are intrinsic to the Irregular line
      -- and survive release of the physical Stone.
      ctx.lastCheck = true
      ctx.lastChoice = mon
    end,
  })

  local REAGENT_REWARDS = {
    EVENT_BEAT_BLAINE = {
      item = IDS.SULFUR, flag = FLAGS.GOT_SULFUR,
      message = "BLAINE left you\\nan ALCHEMICAL\\nSULFUR.",
    },
    EVENT_GOT_MASTER_BALL = {
      item = IDS.MERCURY, flag = FLAGS.GOT_MERCURY,
      message = "SILPH research\\nyielded sealed\\nALCHEMICAL MERCURY.",
    },
    EVENT_RESCUED_MR_FUJI = {
      item = IDS.AETHER, flag = FLAGS.GOT_AETHER,
      message = "MR.FUJI entrusted\\nyou with a trace\\nof AETHER.",
    },
    EVENT_BEAT_GIOVANNI = {
      item = IDS.SALT, flag = FLAGS.GOT_SALT,
      message = "The final VIRIDIAN\\ntrial revealed\\nALCHEMICAL SALT.",
    },
  }

  local function queueReagentNotice(save, message)
    local md = ensureModData(save)
    md.pendingReagentNotice = message
  end

  local function acquireReagent(game, reward)
    game = game or Game
    local save = game and game.save
    if not (save and reward) then return false end
    if flag(save, reward.flag) then return true end

    save.inventory = save.inventory or {}
    if Bag.add(save, reward.item, 1, game.data) then
      setFlag(save, reward.flag, true)
      queueReagentNotice(save, reward.message)
      return true
    end

    local md = ensureModData(save)
    md.pendingReagent = reward.item
    md.pendingReagentFlag = reward.flag
    md.pendingReagentNotice = reward.message
    return false
  end

  local function backfillReagents(game)
    game = game or Game
    local save = game and game.save
    if not save then return end
    for milestone, reward in pairs(REAGENT_REWARDS) do
      if flag(save, milestone) and not flag(save, reward.flag) then
        acquireReagent(game, reward)
      end
    end
  end

  local function retryPendingReagent(game)
    game = game or Game
    local save = game and game.save
    if not save then return end
    local md = ensureModData(save)
    if not (md.pendingReagent and md.pendingReagentFlag) then return end
    save.inventory = save.inventory or {}
    if Bag.add(save, md.pendingReagent, 1, game.data) then
      setFlag(save, md.pendingReagentFlag, true)
      md.pendingReagent = nil
      md.pendingReagentFlag = nil
    end
  end

  mod.events:on("flag.changed", function(ev)
    if not (ev and ev.value) then return end
    local reward = REAGENT_REWARDS[ev.name]
    if reward then acquireReagent(Game, reward) end
  end)

  mod.events:on("game.ready", function(ev)
    local game = (ev and ev.game) or Game
    backfillReagents(game)
  end)

  mod.events:on("map.entered", function(ev)
    local game = (ev and ev.game) or Game
    local save = game and game.save
    local ow = game and game.overworld
    if not (save and ow) then return end

    retryPendingReagent(game)

    local md = ensureModData(save)
    local msg = md.pendingReagentNotice
    if msg and ow.runner and not ow.runner:isRunning() then
      md.pendingReagentNotice = nil
      ow.runner:run({
        { "text_sound", "Get_Key_Item" },
        { "show_text", msg },
      }, {})
    end
  end)

  -- Cinnabar Crucible: one physical Stone, with rebinding only here.
  -- After the four-step material hunt and Rubedo, the Stone can be bound
  -- from the bag. Returning to the Crucible can reclaim an existing bond so
  -- the same relic may be tested on another Pokémon without ever stacking.
  mod.content.map_scripts:register("CINNABAR_LAB_METRONOME_ROOM", {
    priority = 1900,
    talk = {
      TEXT_CINNABARLABMETRONOMEROOM_SCIENTIST1 = {
        { "red_earth:champion_gate" },
        { "jump_if_false", "pre_champion" },

        { "check_item", IDS.PHILOSOPHERS_STONE },
        { "jump_if_true", "loose_stone" },
        { "red_earth:has_bound_stone" },
        { "jump_if_true", "bound_stone" },

        { "check_item", IDS.SALT },
        { "jump_if_false", "vanilla" },
        { "check_item", IDS.SULFUR },
        { "jump_if_false", "vanilla" },
        { "check_item", IDS.MERCURY },
        { "jump_if_false", "vanilla" },
        { "check_item", IDS.AETHER },
        { "jump_if_false", "vanilla" },

        { "show_text",
          "The hidden CRUCIBLE\nresponds to the four\nalchemical substances." },
        { "show_text", "Begin the WORK?" },
        { "choice", { "BEGIN", "NOT YET" } },
        { "jump_if_false", "end" },

        { "show_text", "CALCINATION...\nSULFUR yields its\nimpurity to fire." },
        { "take_item", IDS.SULFUR, 1 },
        { "show_text", "DISSOLUTION...\nMERCURY breaks the\nfixed form." },
        { "take_item", IDS.MERCURY, 1 },
        { "show_text", "SEPARATION...\nSALT preserves what\nmust remain." },
        { "take_item", IDS.SALT, 1 },
        { "show_text", "CONJUNCTION...\nAETHER reunites body,\nwill and change." },
        { "take_item", IDS.AETHER, 1 },
        { "show_text", "RUBEDO." },
        { "give_item", IDS.PHILOSOPHERS_STONE, 1, false },
        { "text_sound", "Get_Key_Item" },
        { "show_text",
          "The PHILOSOPHER'S\nSTONE is complete." },
        { "jump", "end" },

        { "label", "bound_stone" },
        { "show_text",
          "The CRUCIBLE can\nsever the Stone's\ncurrent bond." },
        { "show_text", "Reclaim the Stone?" },
        { "choice", { "RECLAIM", "LEAVE IT" } },
        { "jump_if_false", "end" },
        { "red_earth:reclaim_stone" },
        { "jump_if_false", "reclaim_failed" },
        { "text_sound", "Get_Key_Item" },
        { "show_text",
          "The bond dissolves.\nThe PHILOSOPHER'S\nSTONE is yours again." },
        { "jump", "end" },

        { "label", "reclaim_failed" },
        { "show_text",
          "The bond holds. Make\nroom in the BAG and\ntry again." },
        { "jump", "end" },

        { "label", "loose_stone" },
        { "show_text",
          "The completed Stone\nis unbound. Use it\nfrom the BAG." },
        { "jump", "end" },

        { "label", "vanilla" },
        { "red_earth:base_cinnabar_scientist" },
        { "jump", "end" },

        { "label", "pre_champion" },
        { "show_text",
          "The sealed CRUCIBLE\nremains dormant.\nIt awaits a CHAMPION." },
        { "label", "end" },
      },
    },
  })


  -- ------------------------------------------------------------
  -- Aetheric Transmutation environment classifier.
  -- Battle weather overrides map environment.
  -- ------------------------------------------------------------

  local function upper(value)
    return tostring(value or ""):upper()
  end

  local function weatherTypeName(value)
    local w = upper(value)
    if w:find("RAIN", 1, true) then return "WATER" end
    if w:find("SUN", 1, true) or w:find("HARSH", 1, true) then return "FIRE" end
    if w:find("SAND", 1, true) then return "GROUND" end
    if w:find("HAIL", 1, true) or w:find("SNOW", 1, true)
       or w:find("ICE", 1, true) then return "ICE" end
    return nil
  end

  local function battleWeatherType(battle)
    if not battle then return nil end
    local direct = weatherTypeName(battle._redEarthWeather)
      or weatherTypeName(battle.weather)
      or weatherTypeName(battle.activeWeather)
    if direct then return direct end
    local field = battle.field
    if type(field) == "table" then
      direct = weatherTypeName(field.weather)
        or weatherTypeName(field.activeWeather)
        or weatherTypeName(field.id)
      if direct then return direct end
    end
    return nil
  end

  local WATER_ROUTES = {
    ROUTE_19 = true, ROUTE_20 = true, ROUTE_21 = true,
  }

  local function mapEnvironmentType(game)
    game = game or Game
    local ow = game and game.overworld
    local map = ow and ow.map
    local id = upper(map and (map.id or (map.def and map.def.id)))
    local ambient = map and map.def and (map.def.weather or map.def.ambientWeather)
    local wt = weatherTypeName(ambient)
    if wt then return wt end

    -- Most specific environments first.
    if id:find("ICE", 1, true) or id:find("SNOW", 1, true)
       or id:find("SEAFOAM", 1, true) then return "ICE" end
    if id:find("VOLCANO", 1, true)
       or id == "CINNABAR_ISLAND"
       or id:find("POKEMON_MANSION", 1, true) then return "FIRE" end
    if id:find("DESERT", 1, true) then return "GROUND" end
    if id:find("FOREST", 1, true) or id:find("GROVE", 1, true)
       or id:find("JUNGLE", 1, true) then return "GRASS" end
    if WATER_ROUTES[id] or id:find("OCEAN", 1, true)
       or id:find("SEA_ROUTE", 1, true) then return "WATER" end
    if id:find("CAVE", 1, true) or id:find("TUNNEL", 1, true)
       or id:find("MT_MOON", 1, true) or id:find("VICTORY_ROAD", 1, true)
       or id:find("ROCKY", 1, true) then return "ROCK" end
    return "DRAGON"
  end

  local function stoneAwakened(mon)
    return mon and mon.species == IDS.SOLIPSDION
       and mon.redEarthPhilosophersStone == true
       and mon.redEarthStoneStage == "AWAKENING"
  end

  local function currentSecondary(mon, game, battle)
    if not stoneAwakened(mon) then return "DRAGON" end
    return battleWeatherType(battle) or mapEnvironmentType(game)
  end

  -- Keep the move-list / summary-facing type in sync with the active field.
  -- Damage still clones the move per use below, so this UI value can never
  -- make another Pokémon accidentally inherit Solipsdion's awakened state.
  local function refreshVerdictType(game, battle)
    game = game or (battle and battle.game) or Game
    local def = game and game.data and game.data.moves
      and game.data.moves[IDS.SERAPHS_VERDICT]
    if def then
      def.type = battleWeatherType(battle) or mapEnvironmentType(game)
    end
  end

  local WEATHER_MOVE = {
    RAIN_DANCE = "RAIN",
    SUNNY_DAY = "SUN",
    SANDSTORM = "SAND",
    HAIL = "HAIL",
    SNOWSCAPE = "SNOW",
  }

  local function refreshBattlerType(battle, battler)
    local mon = battler and battler.mon
    if not stoneAwakened(mon) then return end
    battler.curTypes = { "PSYCHIC", currentSecondary(mon, battle and battle.game or Game, battle) }
  end

  local function refreshBattleTypes(battle)
    if not battle then return end
    refreshBattlerType(battle, battle.player)
    refreshBattlerType(battle, battle.enemy)
  end

  mod.events:on("battle.started", function(ev)
    local battle = ev and ev.battle
    refreshBattleTypes(battle)
    refreshVerdictType((battle and battle.game) or Game, battle)
  end)

  mod.events:on("battle.battler_switched", function(ev)
    local battle = ev and ev.battle
    refreshBattlerType(battle, ev and ev.battler)
    refreshVerdictType((battle and battle.game) or Game, battle)
  end)

  mod.events:on("battle.move_used", function(ev)
    local move = ev and ev.move
    local battle = ev and ev.battle
    if not (battle and move) then return end
    local w = WEATHER_MOVE[move.id]
    if w then
      battle._redEarthWeather = w
      battle._redEarthWeatherTurns = 5
      refreshBattleTypes(battle)
      refreshVerdictType((battle and battle.game) or Game, battle)
    end
  end)

  mod.events:on("battle.turn_ended", function(ev)
    local battle = ev and ev.battle
    if not battle then return end
    if battle._redEarthWeatherTurns then
      battle._redEarthWeatherTurns = battle._redEarthWeatherTurns - 1
      if battle._redEarthWeatherTurns <= 0 then
        battle._redEarthWeatherTurns = nil
        battle._redEarthWeather = nil
      end
    end
    refreshBattleTypes(battle)
    refreshVerdictType((battle and battle.game) or Game, battle)

    -- First Condition: ordinary Stone-bound Pokémon perform one restorative
    -- transmutation per battle at critical HP. Solipsdion's awakened Second
    -- Condition supersedes this effect.
    for _, battler in ipairs({ battle.player, battle.enemy }) do
      local mon = battler and battler.mon
      local maxHP = mon and mon.stats and mon.stats.hp
      if mon and mon.redEarthPhilosophersStone == true
         and not stoneAwakened(mon)
         and not stoneRenewalUsed[mon]
         and maxHP and maxHP > 0 and (mon.hp or 0) > 0
         and (mon.hp or 0) <= math.floor(maxHP / 3) then
        local heal = math.max(1, math.floor(maxHP * 0.25))
        mon.hp = math.min(maxHP, mon.hp + heal)
        stoneRenewalUsed[mon] = true
        if battler.curHP ~= nil then battler.curHP = mon.hp end
      end
    end

    -- Reign does not merely hide negative stages from calculations; clear
    -- them so subsequent UI/effects also see the immunity.
    for _, battler in ipairs({ battle.player, battle.enemy }) do
      if reignActive(battle, battler) and battler.stages then
        if (battler.stages.special or 0) < 0 then battler.stages.special = 0 end
        if (battler.stages.speed or 0) < 0 then battler.stages.speed = 0 end
      end
    end
  end)

  mod.events:on("game.ready", function(ev)
    refreshVerdictType((ev and ev.game) or Game, nil)
  end)

  mod.events:on("map.entered", function(ev)
    refreshVerdictType((ev and ev.game) or Game, nil)
  end)

  -- One damage hook handles: Aetheric Seraph type, Solitary Reign Special,
  -- and Distance's one-hit reduction. The inner damage function still owns
  -- crits, STAB and type effectiveness.
  mod.hooks:wrap("battle.damage", function(next, ctx)
    local battle = ctx.battle
    local user = ctx.user
    local target = ctx.target
    local move = ctx.move
    local work = shallowCopy(ctx)

    if move and user and user.mon
       and move.id == IDS.SERAPHS_VERDICT
       and stoneAwakened(user.mon) then
      local m = shallowCopy(move)
      m.type = currentSecondary(user.mon, battle and battle.game or Game, battle)
      work.move = m
      move = m
    end

    local special = moveIsSpecial(move)

    if user and reignActive(battle, user) and special then
      local u = shallowCopy(user)
      u.curStats = shallowCopy(user.curStats)
      u.stages = shallowCopy(user.stages)
      u.curStats.special = math.max(1, math.floor((u.curStats.special or 1) * 1.20))
      if (u.stages.special or 0) < 0 then u.stages.special = 0 end
      work.user = u
    end

    if target and reignActive(battle, target) and special then
      local t = shallowCopy(target)
      t.curStats = shallowCopy(target.curStats)
      t.stages = shallowCopy(target.stages)
      t.curStats.special = math.max(1, math.floor((t.curStats.special or 1) * 1.20))
      if (t.stages.special or 0) < 0 then t.stages.special = 0 end
      work.target = t
    end

    local damage, info = next(work)

    local targetMon = target and target.mon
    if type(damage) == "number" and damage > 0
       and targetMon and LINE[targetMon.species]
       and distanceReady[targetMon] then
      distanceReady[targetMon] = false
      damage = math.max(1, math.floor(damage * 0.75))
    end

    return damage, info
  end)

  -- Reign Speed: clone only the comparison battlers so the live stats are
  -- never permanently multiplied. Negative Speed stages are ignored.
  mod.hooks:wrap("battle.turn_order",
    function(next, a, aMove, b, bMove, ctx)
      local battle = (ctx and ctx.battle) or activeBattle
      -- Gen 1's turn-order hook does not include the BattleState in ctx,
      -- so activeBattle is captured from battle.started and cleared on end.

      local function boosted(x)
        if not reignActive(battle, x) then return x end
        local c = shallowCopy(x)
        c.curStats = shallowCopy(x.curStats)
        c.stages = shallowCopy(x.stages)
        c.curStats.speed = math.max(1, math.floor((c.curStats.speed or 1) * 1.20))
        if (c.stages.speed or 0) < 0 then c.stages.speed = 0 end
        return c
      end

      return next(boosted(a), aMove, boosted(b), bMove, ctx)
    end)


  -- ============================================================
  -- RIVAL GENDER — MALE / FEMALE
  --
  -- Inserted into Oak's intro immediately before the normal rival naming.
  -- Naming remains independent: either counterpart can be given any name.
  -- The choice persists both on save.player and in this mod's save data.
  --
  -- Female presentation target: MELONY.
  -- The converted Melony front and overworld assets ship with this build.
  -- Stock LASS / COOLTRAINER_F remains only as a defensive fallback.
  -- ============================================================

  mod.hooks:wrap("intro.oak_speech.build", function(next, steps, speech)
    steps = next(steps, speech)

    mod.ui.insertStepBefore(steps, "ask_rival_name", {
      id = "red_earth_rival_gender",
      kind = "choice",
      pic = "oak",
      saveKey = "red_earth_rival_gender",
      text = "And your rival?\\nChoose their gender.",
      choices = { "MALE", "FEMALE" },
      values = { "male", "female" },
    })

    mod.ui.insertStepAfter(steps, "red_earth_rival_gender", {
      id = "red_earth_rival_gender_commit",
      kind = "fn",
      run = function(sp, done)
        local g = sp.answers.red_earth_rival_gender or "male"
        g = setRivalGender(sp.game, g)

        for _, row in ipairs(sp.steps or {}) do
          if row.id == "ask_rival_name" then
            if g == "female" then
              row.text = "This is my grand-\\ndaughter. She's been\\nyour rival since\\nyou were a baby.\\f...Erm, what is\\nher name again?"
            else
              row.text = "This is my grand-\\nson. He's been\\nyour rival since\\nyou were a baby.\\f...Erm, what is\\nhis name again?"
            end
          elseif row.id == "confirm_rival_name" then
            if g == "female" then
              row.text = "That's right! I\\nremember now! Her\\nname is {RIVAL}!"
            else
              row.text = "That's right! I\\nremember now! His\\nname is {RIVAL}!"
            end
          end
        end
        done()
      end,
    })

    return steps
  end)

  mod.events:on("intro.oak_speech.answered", function(ev)
    if ev and ev.saveKey == "red_earth_rival_gender" then
      setRivalGender(ev.speech and ev.speech.game or Game, ev.value)
    end
  end)

  mod.events:on("game.ready", function(ev)
    local game = (ev and ev.game) or Game
    local saved = mod.save:get("rival_gender")
    if saved == "male" or saved == "female" then
      setRivalGender(game, saved)
    elseif game and game.save and game.save.player then
      setRivalGender(game, game.save.player.rivalGender or "male")
    end
  end)

  local function femaleRivalOverworldDef(game)
    if imageLoads(MELONY_OVERWORLD) then
      return {
        id = "RED_EARTH_MELONY_RIVAL",
        image = MELONY_OVERWORLD,
        frames = 6,
        walker = true,
        trueColor = true,
        frameWidth = 16,
        frameHeight = 16,
        anchorX = 8,
        anchorY = 16,
      }
    end
    return game and game.data and game.data.sprites
      and game.data.sprites.SPRITE_COOLTRAINER_F
  end

  local function applyRivalOverworldGender(game, ow)
    if rivalGender(game) ~= "female" then return end
    local femaleDef = femaleRivalOverworldDef(game)
    if not femaleDef then return end

    for _, npc in ipairs((ow and ow.npcs) or {}) do
      local def = npc and npc.def
      local trainerClass = def and def.trainerClass
      local textId = def and (def.text or def.textId or def.textConst)
      local objectName = def and (def.name or def.id)
      local isRival = isRivalClass(trainerClass)
        or (type(textId) == "string" and textId:find("RIVAL", 1, true))
        or (type(objectName) == "string" and objectName:find("RIVAL", 1, true))
      if isRival then
        local ok, sprite = pcall(SpriteRenderer.new, femaleDef, npc.id)
        if ok and sprite then
          npc.sprite = sprite
          npc.spriteId = femaleDef.id or "RED_EARTH_MELONY_RIVAL"
        end
      end
    end
  end

  mod.events:on("map.entered", function(ev)
    local game = (ev and ev.game) or Game
    if game and game.overworld then
      applyRivalOverworldGender(game, game.overworld)
    end
  end)

  -- ============================================================
  -- HUMAN ANSEM PLAYER ART
  -- Standalone selector until the user's installed player-selector API is
  -- positively identified; never forces Ansem over Red.
  -- ============================================================

  mod.options:define({
    {
      key = "dynamic_wilds",
      type = "toggle",
      label = "DYNAMIC WILDS",
      default = true,
      help = "ON by default. Wild levels track your strongest healthy Pokemon (-2 to +1) and never scale authored encounters downward.",
    },
    {
      key = "dynamic_trainers",
      type = "toggle",
      label = "DYNAMIC TRAINERS",
      default = true,
      help = "ON by default. Kaizo trainer levels track your strongest healthy Pokemon (+0 to +2) while preserving teams, movesets and AI.",
    },
    {
      key = "player_skin",
      type = "choice",
      label = "PLAYER SKIN",
      default = "red",
      choices = {
        { "DEFAULT RED", "red" },
        { "HUMAN ANSEM", "ansem" },
      },
      help = "White-haired Human Ansem only. Restart after changing.",
    },
  })

  local okSkin, selectedSkin = pcall(mod.options.get, mod.options, "player_skin")
  if not okSkin then selectedSkin = "red" end
  if selectedSkin ~= "red" then
    -- Standard 16x16 Gen1 walker geometry keeps collision/fishing/special
    -- states aligned while still using the supplied Human Ansem artwork.
    mod.content.sprites:patch("SPRITE_RED", {
      image = asset("assets/player/ansem_overworld.png"),
      frames = 6,
      walker = true,
      trueColor = true,
      frameWidth = 16,
      frameHeight = 16,
      anchorX = 8,
      anchorY = 16,
    })

    mod.content.sprites:register("RED_EARTH_ANSEM_BIKE", {
      image = asset("assets/player/ansem_bike.png"),
      frames = 6,
      walker = true,
      trueColor = true,
      frameWidth = 16,
      frameHeight = 16,
      anchorX = 8,
      anchorY = 16,
    })

    mod.content.sprites:register("RED_EARTH_ANSEM_SURF", {
      image = asset("assets/player/ansem_surf.png"),
      frames = 6,
      walker = true,
      trueColor = true,
      frameWidth = 16,
      frameHeight = 16,
      anchorX = 8,
      anchorY = 16,
    })

    mod.content.field:patch("playerSprites", {
      walk = "SPRITE_RED",
      bike = "RED_EARTH_ANSEM_BIKE",
      surf = "RED_EARTH_ANSEM_SURF",
    })

    mod.content.field:patch("playerPics", {
      back = asset("assets/player/ansem_back.png"),
      front = asset("assets/player/ansem_front.png"),
    })

    -- FishingAnim normally writes Red-specific bottom-row tiles. These
    -- replacements redraw Ansem's own lower row so the rod animation never
    -- causes a sudden Red sprite fragment.
    mod.content.field:patch("overworldFx", {
      redFishFront = { path = asset("assets/player/ansem_fish_front.png") },
      redFishBack  = { path = asset("assets/player/ansem_fish_back.png") },
      redFishSide  = { path = asset("assets/player/ansem_fish_side.png") },
    })
  end

  -- ============================================================
  -- POST-LOAD INTEGRATION
  -- Wilds owns follower runtime; Crystal Animated Sprites owns the standard
  -- battle shiny reveal/SFX. This mod only supplies custom authored art and
  -- the missing follower sparkle presentation.
  -- ============================================================

  mod.events:once("mods.loaded", function()
    -- Female rival presentation. Prefer the supplied Melony art; stock female
    -- trainer art remains a defensive fallback if an asset is unavailable.
    local OakSpeech = require("src.ui.OakSpeech")
    if not OakSpeech._redEarthRivalGender then
      local priorResolvePic = OakSpeech.resolvePic
      OakSpeech.resolvePic = function(game, desc, speech)
        if rivalGender(game) == "female" then
          local wantsRival = desc == "rival"
            or (type(desc) == "table" and desc.type == "trainer"
                and isRivalClass(desc.id))
          if wantsRival then
            if imageLoads(MELONY_FRONT) then
              local ok, img = pcall(Assets.image, MELONY_FRONT)
              if ok and img then return img, false, true end
            end
            desc = { type = "trainer", id = "OPP_LASS" }
          end
        end
        return priorResolvePic(game, desc, speech)
      end
      OakSpeech._redEarthRivalGender = true
    end

    if not BattleState._redEarthRivalGender then
      local priorTrainerSprite = BattleState.trainerSprite
      BattleState.trainerSprite = function(data, trainer, oppClass, partyIndex)
        if rivalGender(Game) == "female" and isRivalClass(oppClass) then
          if imageLoads(MELONY_FRONT) then
            local ok, img = pcall(Assets.image, MELONY_FRONT)
            if ok and img then return img end
          end
          local lass = data and data.trainers and data.trainers.OPP_LASS
          if lass then
            return priorTrainerSprite(data, lass, "OPP_LASS", 1)
          end
        end
        return priorTrainerSprite(data, trainer, oppClass, partyIndex)
      end
      BattleState._redEarthRivalGender = true
    end

    -- Wilds of Kanto 2.1.9+ is the follower owner. Intercept its central
    -- follower sprite service for only the Irregular line. This preserves the
    -- normal Wilds lifecycle/selection logic while serving our authored
    -- normal/shiny sheets and metadata for the 8-direction draw adapter below.
    local wilds = mod:find("overworld_wild_spawns")
    local wildsEx = wilds and wilds.exports
    local service = wildsEx and wildsEx.follower and wildsEx.follower.spriteService
    if service and type(service.resolveFollowerSprite) == "function"
       and not service._redEarthIrregularWrapped then
      local priorResolveFollower = service.resolveFollowerSprite
      function service:resolveFollowerSprite(opts)
        opts = opts or {}
        local species = opts.species
        local art = species and ART[species]
        if art then
          local shinyFollow = opts.shiny == true
          local role = opts.role or "primary"
          local id = role == "player_controlled"
            and "SPRITE_PLAYER_POKEMON" or "SPRITE_WILDS_FOLLOWER_MON"
          return {
            id = id,
            image = shinyFollow and art.shinyFollower or art.normalFollower,
            frames = 6,
            walker = true,
            trueColor = true,
            frameWidth = 16,
            frameHeight = 16,
            anchorX = 8,
            anchorY = 16,
            providerId = "red_earth_irregular",
            role = role,
            surface = opts.surface or "land",
            fallback = false,
            redEarthSpecies = species,
            redEarthShiny = shinyFollow,
            redEarthFollower8 = shinyFollow and art.shinyFollower8
              or art.normalFollower8,
          }
        end
        return priorResolveFollower(self, opts)
      end
      service._redEarthIrregularWrapped = true
    end

    if wildsEx and type(wildsEx.refreshAllEntitySprites) == "function" then
      pcall(wildsEx.refreshAllEntitySprites, Game)
    end

    -- Summary screen: install after presentation mods so the custom line's
    -- authored menu portrait always wins. During draw, an awakened Solipsdion
    -- temporarily exposes its live Psychic/X Aetheric typing to the UI.
    local SummaryMenu = require("src.ui.SummaryMenu")
    if not SummaryMenu._redEarthWrapped then
      local priorNew = SummaryMenu.new
      SummaryMenu.new = function(game, mon, ...)
        local self = priorNew(game, mon, ...)
        local art = mon and ART[mon.species]
        if art then
          local chosen = isShiny(mon) and art.shinyMenu or art.normalMenu
          local ok, img = pcall(Assets.image, chosen)
          if ok and img then
            self.sprite = img
            self.spriteTrueColor = true
          end
        end
        return self
      end

      local priorDraw = SummaryMenu.draw
      function SummaryMenu:draw(...)
        local mon = self.mon
        local def = mon and self.game and self.game.data
          and self.game.data.pokemon[mon.species]
        if not (def and stoneAwakened(mon)) then
          return priorDraw(self, ...)
        end

        local oldTypes = def.types
        def.types = { "PSYCHIC", currentSecondary(mon, self.game, nil) }
        local ok, err = pcall(priorDraw, self, ...)
        def.types = oldTypes
        if not ok then error(err, 0) end
      end
      SummaryMenu._redEarthWrapped = true
    end

    local function activeFollowerMon(game)
      game = game or Game
      if wildsEx and type(wildsEx.getActiveFollowerMon) == "function" then
        local ok, mon = pcall(wildsEx.getActiveFollowerMon, game, true)
        if ok and mon then return mon end
      end
      local party = game and game.save and game.save.party or {}
      local idx = game and game.save and tonumber(game.save.followerPartyIndex)
      if idx and party[idx] and (party[idx].hp or 0) > 0 then return party[idx] end
      for _, mon in ipairs(party) do
        if mon and (mon.hp or 0) > 0 then return mon end
      end
      return party[1]
    end

    -- Repeating visual-only overworld sparkle. Battle sparkle + SFX are owned
    -- by the required Crystal Animated Sprites mod, preventing two battle
    -- reveal systems from firing at once.
    local function drawFollowerSparkles(key, x, y)
      if not (love and love.graphics and love.timer and key) then return end
      local t = love.timer.getTime and love.timer.getTime() or 0
      local phase = t % 2.8
      if phase > 0.86 then return end
      local p = phase / 0.86
      local radius = 5 + math.floor(p * 7)
      local blink = math.floor(phase * 18) % 2 == 0
      local size = blink and 2 or 1
      if PaletteFX.markTrueColor then
        PaletteFX.markTrueColor(x - 15, y - 15, 30, 30)
      end
      local r, g, b, a = 1, 1, 1, 1
      if love.graphics.getColor then r, g, b, a = love.graphics.getColor() end
      love.graphics.setColor(1, 1, 1, 1)
      local points = {
        { x - radius, y - math.floor(radius * 0.45) },
        { x + radius, y - math.floor(radius * 0.20) },
        { x - math.floor(radius * 0.25), y + radius },
        { x + math.floor(radius * 0.35), y - radius },
      }
      for i, pt in ipairs(points) do
        if ((i + math.floor(phase * 10)) % 2) == 0 or p < 0.45 then
          love.graphics.rectangle("fill", pt[1] - size, pt[2], size * 2 + 1, 1)
          love.graphics.rectangle("fill", pt[1], pt[2] - size, 1, size * 2 + 1)
        end
      end
      love.graphics.setColor(r, g, b, a)
    end

    -- Full 8-direction Irregular follower draw. Vanilla SpriteRenderer mirrors
    -- RIGHT from LEFT; our canonical uploads contain a real right-facing view,
    -- so custom followers use an 8-frame sheet. Standard followers still use
    -- Wilds untouched, with the sparkle overlay added only for the selected
    -- genuine-shiny follower (Fennekin / third starter included).
    if not SpriteRenderer._redEarth8Dir then
      local priorDraw = SpriteRenderer.draw
      function SpriteRenderer:draw(px, py, camX, camY, facing, walkPhase,
          stepFlip, topHalf, forceFlip, frameOverride, oamRow)
        local def = self.def or {}
        local customPath = def.redEarthFollower8
        local x, y
        if self.getScreenOrigin then
          x, y = self:getScreenOrigin(px, py, camX or 0, camY or 0)
        else
          x = math.floor(px - (camX or 0))
          y = math.floor(py - (camY or 0)) - 4
        end

        if customPath then
          local ok, img = pcall(Assets.image, customPath)
          if ok and img and love and love.graphics then
            local stand = { down = 0, up = 1, left = 2, right = 3 }
            local walk = { down = 4, up = 5, left = 6, right = 7 }
            local frame = (walkPhase == 1 and walk[facing]) or stand[facing] or 0
            local iw, ih = img:getDimensions()
            local quad = love.graphics.newQuad(0, frame * 16, 16, 16, iw, ih)
            if PaletteFX.markTrueColor then
              PaletteFX.markTrueColor(x, y, 16, 16)
            end
            love.graphics.setColor(1, 1, 1, 1)
            love.graphics.draw(img, quad, x, y)
            if def.redEarthShiny then
              drawFollowerSparkles(
                "red-earth:" .. tostring(def.redEarthSpecies), x + 8, y + 5)
            end
            return
          end
        end

        local result = priorDraw(self, px, py, camX, camY, facing, walkPhase,
          stepFlip, topHalf, forceFlip, frameOverride, oamRow)

        local id = def.id
        local followerLike = def.role == "primary" or def.role == "player_controlled"
          or id == "SPRITE_PLAYER_POKEMON"
          or id == "SPRITE_PIKACHU"
        if followerLike then
          local mon = activeFollowerMon(Game)
          if mon and isShiny(mon) then
            drawFollowerSparkles(
              "red-earth:selected:" .. tostring(mon.species), x + 8, y + 5)
          end
        end
        return result
      end
      SpriteRenderer._redEarth8Dir = true
    end
  end)

  -- ============================================================
  -- Public diagnostics/helpers
  -- ============================================================

  mod.exports.ids = IDS
  mod.exports.flags = FLAGS
  mod.exports.isShiny = isShiny
  mod.exports.giveGuaranteedShiny = giveGuaranteedShiny
  mod.exports.reignActive = reignActive
  mod.exports.mapEnvironmentType = mapEnvironmentType
  mod.exports.currentSecondary = currentSecondary
  mod.exports.rivalGender = rivalGender
  mod.exports.setRivalGender = setRivalGender
  mod.exports.backfillReagents = backfillReagents
  mod.exports.strongestHealthy = strongestHealthy
  mod.exports.dynamicWildTarget = dynamicWildTarget
  mod.exports.dynamicScalingEnabled = function()
    return {
      wilds = optionEnabled("dynamic_wilds", true),
      trainers = optionEnabled("dynamic_trainers", true),
    }
  end

  mod.log:info(
    "Red Earth: The Irregular and The Philosopher Stones v1.0.1 loaded — dynamic Kaizo scaling ON by default; Irregular line, Stone, shiny starter route, Ansem and Melony ready")
end
