-- Structural smoke test for Red Earth: The Irregular and The Philosopher Stones v1.0.0.
-- It executes the entry chunk against small public-API-shaped mocks. This is
-- not a gameplay emulator; CI separately validates source/assets/package shape.

local root = assert(arg[1], "pass mod root as argv[1]")

local basePokemon = {
  BULBASAUR={dex=1,baseStats={hp=45,attack=49,defense=49,speed=45,special=65}},
  CHARMANDER={dex=4,baseStats={hp=39,attack=52,defense=43,speed=65,special=50}},
  SQUIRTLE={dex=7,baseStats={hp=44,attack=48,defense=65,speed=43,special=50}},
  CHIKORITA={dex=152,baseStats={hp=45,attack=49,defense=65,speed=45,special=65}},
  TREECKO={dex=252,baseStats={hp=40,attack=45,defense=35,speed=70,special=65}},
  TURTWIG={dex=387,baseStats={hp=55,attack=68,defense=64,speed=31,special=45}},
  SNIVY={dex=495,baseStats={hp=45,attack=45,defense=55,speed=63,special=55}},
  CHESPIN={dex=650,baseStats={hp=56,attack=61,defense=65,speed=38,special=48}},
  FENNEKIN={dex=653,baseStats={hp=40,attack=45,defense=40,speed=60,special=62}},
  FROAKIE={dex=656,baseStats={hp=41,attack=56,defense=40,speed=71,special=62}},
  ROWLET={dex=722,baseStats={hp=68,attack=55,defense=55,speed=42,special=50}},
}

local Game = {
  save = {
    flags = {}, player = {}, inventory = {}, party = {}, boxes = {},
    hallOfFame = { count = 1 }, modData = {}, pokedex={seen={},owned={}},
  },
  data = {
    pokemon = basePokemon,
    moves = {}, items = {},
    trainers = {
      OPP_LASS = { pic = "lass.png" },
      OPP_RIVAL1 = { pic = "rival.png" },
      OPP_RIVAL2 = { pic = "rival.png" },
      OPP_RIVAL3 = { pic = "rival.png" },
    },
    sprites = {
      SPRITE_COOLTRAINER_F = { id="SPRITE_COOLTRAINER_F", image="female.png",
        frames=6, walker=true },
    },
    field = {}, text = {},
  },
  overworld = { npcs = {}, map={id="PALLET_TOWN",def={}},
    runner = { isRunning=function() return false end, run=function() end } },
}
Game.stack = { pop=function() end, push=function() end }

local Stats = {}
function Stats.isShiny(d)
  if not d then return false end
  local a=d.attack
  local okAtk = a==2 or a==3 or a==6 or a==7 or a==10 or a==11 or a==14 or a==15
  return okAtk and d.defense==10 and d.speed==10 and d.special==10
end
function Stats.calc(def, level, dvs, statExp)
  return { hp=100, attack=50, defense=50, speed=50, special=50 }
end

local Assets = {}
function Assets.image(path)
  return { path=path, getDimensions=function() return 56,56 end }
end

local BattleState = {
  trainerSprite=function(data, trainer) return trainer and trainer.pic or "trainer" end,
}

local SpriteRenderer = {}
function SpriteRenderer.new(def, id)
  local o={ def=def, id=id }
  function o:getScreenOrigin() return 0,0 end
  return o
end
function SpriteRenderer:draw() end
function SpriteRenderer.invalidate() end

local PaletteFX = { markTrueColor=function() end }
local MapScripts = { baseTalk=function() return nil end }

local Bag = {}
function Bag.add(save, id, qty, data)
  save.inventory[id] = (save.inventory[id] or 0) + (qty or 1)
  return true
end
function Bag.remove(save,id,qty)
  local n=save.inventory[id] or 0
  if n < (qty or 1) then return false end
  save.inventory[id]=n-(qty or 1)
  return true
end

local Commands = {}
function Commands.give_pokemon(ctx, species, level)
  local mon={species=species,level=level,hp=100,stats={hp=100},dvs={attack=1,defense=1,speed=1,special=1}}
  table.insert(ctx.save.party,mon)
  ctx.lastCheck=true; ctx.addedToParty=true
  ctx.game.data.pokemon[species]=ctx.game.data.pokemon[species] or {baseStats={hp=40,attack=40,defense=40,speed=40,special=40}}
end

local SummaryMenu = {}
function SummaryMenu.new(game, mon)
  return setmetatable({game=game,mon=mon},{__index=SummaryMenu})
end
function SummaryMenu:draw() end

local OakSpeech = {}
function OakSpeech.resolvePic(game, desc, speech)
  return Assets.image("oakpic.png"), false, true
end

package.preload["src.pokemon.Stats"] = function() return Stats end
package.preload["src.script.Commands"] = function() return Commands end
package.preload["src.render.Assets"] = function() return Assets end
package.preload["src.battle.BattleState"] = function() return BattleState end
package.preload["src.render.SpriteRenderer"] = function() return SpriteRenderer end
package.preload["src.render.PaletteFX"] = function() return PaletteFX end
package.preload["src.core.Game"] = function() return Game end
package.preload["src.script.MapScripts"] = function() return MapScripts end
package.preload["src.inventory.Bag"] = function() return Bag end
package.preload["src.ui.SummaryMenu"] = function() return SummaryMenu end
package.preload["src.ui.OakSpeech"] = function() return OakSpeech end
package.preload["src.ui.Menu"] = function()
  return { new=function(game,items,opts) return {items=items,opts=opts} end }
end

_G.love = {
  timer={ getTime=function() return 0 end },
  graphics={
    setColor=function() end, getColor=function() return 1,1,1,1 end,
    draw=function() end, rectangle=function() end,
    newQuad=function() return {} end,
  },
}

local registries = {}
local function registry(name, backing)
  local r={rows=backing or {},patches={}}
  function r:register(id,value) self.rows[id]=value end
  function r:patch(id,value)
    self.patches[id]=value
    local prior=self.rows[id]
    if type(prior)=="table" and type(value)=="table" then
      for k,v in pairs(value) do prior[k]=v end
    elseif prior==nil then self.rows[id]=value end
  end
  function r:override(id,value) self.rows[id]=value end
  function r:get(id) return self.rows[id] end
  function r:each() return pairs(self.rows) end
  registries[name]=r
  return r
end

local eventHandlers, onceHandlers, hookHandlers = {}, {}, {}
local modSave = {}

local followerService={}
function followerService:resolveFollowerSprite(opts)
  return {id="SPRITE_WILDS_FOLLOWER_MON",image="fallback.png",frames=6,walker=true,trueColor=true,role=opts and opts.role}
end
local wilds={exports={
  follower={spriteService=followerService},
  getActiveFollowerMon=function(game) return game.save.party[1] end,
  refreshAllEntitySprites=function() end,
}}

local mod={
  id="red_earth_irregular", path=root, exports={},
  assets={path=function(self,rel) return root.."/"..rel end},
  content={
    pokemon=registry("pokemon",Game.data.pokemon),
    moves=registry("moves",Game.data.moves),
    items=registry("items",Game.data.items),
    item_effects=registry("item_effects"), commands=registry("commands"),
    map_scripts=registry("map_scripts"), sprites=registry("sprites",Game.data.sprites),
    field=registry("field",Game.data.field), constants=registry("constants"),
  },
  events={}, hooks={}, options={}, ui={}, save={},
  log={info=function() end,warn=function() end},
}
function mod:find(id)
  if id=="overworld_wild_spawns" then return wilds end
  return nil
end
function mod.events:on(name,fn)
  eventHandlers[name]=eventHandlers[name] or {}; table.insert(eventHandlers[name],fn)
end
function mod.events:once(name,fn)
  onceHandlers[name]=onceHandlers[name] or {}; table.insert(onceHandlers[name],fn)
end
function mod.hooks:wrap(name,fn) hookHandlers[name]=fn end
function mod.options:define(rows) mod.options.defs=rows end
function mod.options:get(key) return "red" end
function mod.ui.insertStepBefore(steps,anchor,step)
  for i,row in ipairs(steps) do if row.id==anchor then table.insert(steps,i,step); return steps end end
  table.insert(steps,step); return steps
end
function mod.ui.insertStepAfter(steps,anchor,step)
  for i,row in ipairs(steps) do if row.id==anchor then table.insert(steps,i+1,step); return steps end end
  table.insert(steps,step); return steps
end
function mod.save:get(k) return modSave[k] end
function mod.save:set(k,v) modSave[k]=v end

local entry=assert(dofile(root.."/main.lua"))
entry(mod)

assert(registries.pokemon.rows.RED_EARTH_PSYDREN,"Psydren registered")
assert(registries.pokemon.rows.RED_EARTH_VESPERIS,"Vesperis registered")
assert(registries.pokemon.rows.RED_EARTH_SOLIPSDION,"Solipsdion registered")
assert(registries.moves.rows.RED_EARTH_SERAPHS_VERDICT,"Seraph's Verdict registered")
assert(registries.commands.rows["red_earth:give_shiny"],"shiny gift command registered")
assert(registries.commands.rows["red_earth:regional_grass_choice"],"regional grass command registered")
assert(registries.items.rows.RED_EARTH_PHILOSOPHERS_STONE,"Stone item registered")
assert(registries.map_scripts.rows.OAKS_LAB,"Oak lab override registered")
assert(registries.map_scripts.rows.CINNABAR_LAB_METRONOME_ROOM,"Crucible script registered")

local oakHook=assert(hookHandlers["intro.oak_speech.build"],"Oak speech hook registered")
local steps={{id="ask_rival_name"},{id="name_rival"},{id="confirm_rival_name"}}
local built=oakHook(function(x) return x end,steps,{})
local foundGender=false
for _,row in ipairs(built) do if row.id=="red_earth_rival_gender" then foundGender=true end end
assert(foundGender,"rival gender choice inserted")

for _,fn in ipairs(eventHandlers["game.ready"] or {}) do fn({game=Game}) end
for _,fn in ipairs(onceHandlers["mods.loaded"] or {}) do fn({}) end

assert(followerService._redEarthIrregularWrapped==true,"Wilds follower service wrapped")
assert(type(mod.exports.giveGuaranteedShiny)=="function","shiny helper exported")
assert(type(mod.exports.currentSecondary)=="function","Aetheric helper exported")
assert(type(mod.exports.rivalGender)=="function","rival-gender helper exported")

-- Guaranteed shiny DV contract: all three gift paths share this helper.
local ctx={game=Game,save=Game.save}
local result=mod.exports.giveGuaranteedShiny(ctx,"FENNEKIN",5,{})
assert(result.ok and result.mon.shiny==true,"Fennekin gift is true shiny")
assert(Stats.isShiny(result.mon.dvs),"Fennekin DVs are shiny-compatible")
assert(result.mon.dvs.hp==8,"shiny HP DV is correctly derived")

print("RED_EARTH_MOCK_SMOKE_PASS")
