# Red Earth: The Irregular and The Philosopher Stones — v1.0.0

A unified Gen1Recomp content mod for **Red Earth: The Irregular and The Philosopher Stones**.
It replaces the earlier split Irregular Origin / Philosopher Stones / Kaizo Bridge stack with one owned mod.

## Irregular line

- **Psydren** — Psychic/Water — 55 / 40 / 65 / 45 / 70
- **Vesperis** — Psychic/Ghost — 70 / 55 / 75 / 80 / 95
- **Solipsdion** — Psychic/Dragon — 95 / 85 / 105 / 105 / 125
- Canonical seven-wing Solipsdion anatomy: two flight wings, four hand-wings, one crown wing.
- Authored normal and shiny battle front/back, menu, icon, follower and true right-facing follower art.
- The line uses a mechanical **Modest** nature layer: +10% Special, -10% Attack.

## Starter route

Oak's Lab is authored as a three-Pokémon route:

1. Guaranteed genuine-shiny **Psydren**.
2. Guaranteed genuine-shiny **Fennekin**; the rival receives the Froakie line.
3. Optional guaranteed genuine-shiny Grass starter chosen from the existing Kanto-through-Alola region set.

All three gifts receive Gen-2-compatible shiny DVs and `mon.shiny = true`; evolution keeps the same Pokémon record/DVs. The required Crystal Animated Sprites dependency owns the normal battle shiny reveal and SFX. Wilds of Kanto owns follower runtime; this mod adds the custom line's authored shiny walkers and a repeating visual shiny follower sparkle, including when Fennekin or the third starter is selected to follow.

## Passives

**Distance** arms whenever an Irregular enters battle. The first damaging hit that connects deals 25% less damage, then Distance breaks until that Pokémon leaves and re-enters.

**Solitary Reign** belongs to Solipsdion. While it is the only conscious Pokémon on its side, Special and Speed are effectively 20% higher and negative Special/Speed stages are suppressed. Party position does not matter.

## Philosopher's Stone

Four story-earned reagents feed the hidden Cinnabar Crucible after the player becomes Champion:

- Sulfur — Blaine
- Mercury — Silph Co. Master Ball milestone
- Aether — Mr. Fuji rescue
- Salt — final Giovanni victory

The Crucible performs Calcination → Dissolution → Separation → Conjunction → Rubedo. There is one physical Philosopher's Stone. Binding consumes the loose item into one Pokémon; it cannot be stacked or rebound elsewhere until the Crucible severs the current bond and returns the Stone.

Ordinary Pokémon receive the **First Condition**: once per battle at one-third HP or less, restore 25% max HP. Psydren resonates, Vesperis communes, and Solipsdion awakens the **Second Condition — Aetheric Transmutation**.

An awakened Solipsdion remains Psychic primary and changes its secondary type by field:

- neutral / ordinary indoor — Dragon
- harsh sun / volcanic — Fire
- rain / ocean / water route — Water
- snow / hail / ice cavern — Ice
- sand / desert — Ground
- cave / rocky underground — Rock
- forest / overgrowth — Grass

Active battle weather overrides the map until the weather ends. **Seraph's Verdict** follows the current secondary type. Summary typing is updated dynamically.

## Presentation

- **Human Ansem** is an optional player skin, not forced. It includes walk, bike, surf, fishing, trainer front/back and portrait assets.
- Oak's intro adds an independent **male / female rival** choice before naming. Female rival presentation uses the supplied Melony art and persists through overworld and trainer battles.
- Wilds of Kanto 2.1.9+ is the follower owner. No Followers EX or PokéPC duplicate runtime is required.

## Required mods

- `gen1_kaizo >=0.8.3 <1.0.0`
- `overworld_wild_spawns >=2.1.9 <3.0.0`
- `crystal_animated_sprites_with_shiny_visuals >=2.0.3 <3.0.0`

`DRAMALESS_SHAPE >=2.0.4 <3.0.0` is an optional presentation integration and is included in the intended Red Earth cart.

## Compatibility

The mod deliberately conflicts with the older split `irregular_origin`, `philosopher_stones`, and `red_earth_kaizo_bridge` mods, plus alternate starter/shiny/follower stacks that would duplicate the same hooks. Use the unified v1.0.0 mod instead of layering those older components underneath it.
