-- Red Earth Irregular Upgrade v1.0.0
-- Layered on top of the known-good Irregular Origin v1.0.9.
-- This patch deliberately does NOT register species, starters, Stones,
-- player skins, or rival presentation. It only upgrades the Irregular line.

local IDS = {
  PSYDREN = "IRR_PSYDREN",
  VESPERIS = "IRR_VESPERIS",
  SOLIPSDION = "IRR_SOLIPSDION",
}
local IRREGULAR = {
  [IDS.PSYDREN] = true,
  [IDS.VESPERIS] = true,
  [IDS.SOLIPSDION] = true,
}
local SHINY_ATTACK_DVS = {
  [2]=true,[3]=true,[6]=true,[7]=true,
  [10]=true,[11]=true,[14]=true,[15]=true,
}
local SPECIAL_TYPES = {
  FIRE=true, WATER=true, GRASS=true, ELECTRIC=true,
  ICE=true, PSYCHIC=true, DRAGON=true,
}

return function(mod)
  local function asset(rel)
    return mod.path .. "/" .. rel
  end

  local ART = {
    [IDS.PSYDREN] = {
      front=asset("assets/pokemon/psydren/normal_front.png"),
      back=asset("assets/pokemon/psydren/normal_back.png"),
      menu=asset("assets/pokemon/psydren/normal_menu.png"),
      icon=asset("assets/pokemon/psydren/normal_icon.png"),
      follower=asset("assets/pokemon/psydren/normal_follower.png"),
      follower8=asset("assets/pokemon/psydren/normal_follower_8dir.png"),
      frontShiny=asset("assets/pokemon/psydren/shiny_front.png"),
      backShiny=asset("assets/pokemon/psydren/shiny_back.png"),
      menuShiny=asset("assets/pokemon/psydren/shiny_menu.png"),
      iconShiny=asset("assets/pokemon/psydren/shiny_icon.png"),
      followerShiny=asset("assets/pokemon/psydren/shiny_follower.png"),
      follower8Shiny=asset("assets/pokemon/psydren/shiny_follower_8dir.png"),
    },
    [IDS.VESPERIS] = {
      front=asset("assets/pokemon/vesperis/normal_front.png"),
      back=asset("assets/pokemon/vesperis/normal_back.png"),
      menu=asset("assets/pokemon/vesperis/normal_menu.png"),
      icon=asset("assets/pokemon/vesperis/normal_icon.png"),
      follower=asset("assets/pokemon/vesperis/normal_follower.png"),
      follower8=asset("assets/pokemon/vesperis/normal_follower_8dir.png"),
      frontShiny=asset("assets/pokemon/vesperis/shiny_front.png"),
      backShiny=asset("assets/pokemon/vesperis/shiny_back.png"),
      menuShiny=asset("assets/pokemon/vesperis/shiny_menu.png"),
      iconShiny=asset("assets/pokemon/vesperis/shiny_icon.png"),
      followerShiny=asset("assets/pokemon/vesperis/shiny_follower.png"),
      follower8Shiny=asset("assets/pokemon/vesperis/shiny_follower_8dir.png"),
    },
    [IDS.SOLIPSDION] = {
      front=asset("assets/pokemon/solipsdion/normal_front.png"),
      back=asset("assets/pokemon/solipsdion/normal_back.png"),
      menu=asset("assets/pokemon/solipsdion/normal_menu.png"),
      icon=asset("assets/pokemon/solipsdion/normal_icon.png"),
      follower=asset("assets/pokemon/solipsdion/normal_follower.png"),
      follower8=asset("assets/pokemon/solipsdion/normal_follower_8dir.png"),
      frontShiny=asset("assets/pokemon/solipsdion/shiny_front.png"),
      backShiny=asset("assets/pokemon/solipsdion/shiny_back.png"),
      menuShiny=asset("assets/pokemon/solipsdion/shiny_menu.png"),
      iconShiny=asset("assets/pokemon/solipsdion/shiny_icon.png"),
      followerShiny=asset("assets/pokemon/solipsdion/shiny_follower.png"),
      follower8Shiny=asset("assets/pokemon/solipsdion/shiny_follower_8dir.png"),
    },
  }

  local function isIrregular(mon)
    return mon and IRREGULAR[mon.species] == true
  end

  local function isVisualShiny(mon)
    if not mon then return false end
    if mon.shiny == true or mon.isShiny == true then return true end
    local d = mon.dvs
    if type(d) ~= "table" then return false end
    return tonumber(d.defense) == 10
      and tonumber(d.speed) == 10
      and tonumber(d.special) == 10
      and SHINY_ATTACK_DVS[tonumber(d.attack)] == true
  end

  local function ensureMetadata(mon)
    if not isIrregular(mon) then return end
    if not mon.redEarthNature then mon.redEarthNature = "MODEST" end
    if isVisualShiny(mon) then mon.shiny = true end
    mon.redEarthIrregular = true
  end

  local function allMons(save, fn)
    for _,m in ipairs(save and save.party or {}) do fn(m) end
    for _,box in ipairs(save and save.boxes or {}) do
      for _,m in ipairs(box or {}) do fn(m) end
    end
    for _,m in ipairs(save and save.box or {}) do fn(m) end
    if save and save.daycare and save.daycare.mon then fn(save.daycare.mon) end
  end

  -- Keep the original species registration from Irregular Origin intact;
  -- patch only final normal art and stage-specific battle scale.
  local pokemon = mod.content.pokemon
  if pokemon and pokemon:get(IDS.PSYDREN) then
    pokemon:patch(IDS.PSYDREN, {
      spriteFront=ART[IDS.PSYDREN].front,
      spriteBack=ART[IDS.PSYDREN].back,
      trueColor=true,
      battleScaleFront=0.94,
      battleScaleBack=0.94,
    })
  end
  if pokemon and pokemon:get(IDS.VESPERIS) then
    pokemon:patch(IDS.VESPERIS, {
      spriteFront=ART[IDS.VESPERIS].front,
      spriteBack=ART[IDS.VESPERIS].back,
      trueColor=true,
      battleScaleFront=1.00,
      battleScaleBack=1.00,
    })
  end
  if pokemon and pokemon:get(IDS.SOLIPSDION) then
    pokemon:patch(IDS.SOLIPSDION, {
      spriteFront=ART[IDS.SOLIPSDION].front,
      spriteBack=ART[IDS.SOLIPSDION].back,
      trueColor=true,
      battleScaleFront=1.08,
      battleScaleBack=1.05,
    })
  end

  local function artFor(ctx)
    if not ctx then return nil end
    local species = ctx.species or (ctx.mon and ctx.mon.species)
    return ART[species]
  end

  -- Highest Irregular art authority: normal/shiny front, back and menu art.
  -- The custom shiny PNG is selected directly, so no generated recolor is
  -- required or applied by this patch.
  mod.hooks:wrap("pokemon.sprite", function(next, path, ctx)
    local art = artFor(ctx)
    if not art then return next(path, ctx) end
    ctx.trueColor = true
    local shiny = isVisualShiny(ctx.mon)
    if ctx.kind == "summary" or ctx.kind == "dex" or ctx.kind == "menu" then
      return shiny and art.menuShiny or art.menu
    end
    if ctx.side == "back" then
      return shiny and art.backShiny or art.back
    end
    return shiny and art.frontShiny or art.front
  end, 300)

  mod.hooks:wrap("pokemon.icon", function(next, path, ctx)
    local art = artFor(ctx)
    if not art then return next(path, ctx) end
    ctx.trueColor = true
    return isVisualShiny(ctx.mon) and art.iconShiny or art.icon
  end, 300)

  -- Wilds remains the follower runtime owner. This patch replaces only the
  -- three Irregular species on Wilds' Pokedex provider and delegates all other
  -- species to the provider already installed by the stable stack.
  local followerInstalled = false
  local function installFollowerProvider(game)
    if followerInstalled or type(mod.find) ~= "function" then return end
    local ok, wilds = pcall(function() return mod:find("overworld_wild_spawns") end)
    local ex = ok and wilds and wilds.exports
    if not (ex and type(ex.getSpriteProvider)=="function"
        and type(ex.registerSpriteProvider)=="function") then return end
    local okBase, base = pcall(ex.getSpriteProvider, "pokedex")
    if not okBase or type(base) ~= "table" then return end
    if base.__redEarthIrregularUpgrade then
      followerInstalled = true
      return
    end

    local wrapper = { id="pokedex", __redEarthIrregularUpgrade=true }
    function wrapper:isAvailable(_game)
      return true, "Red Earth final Irregular follower art"
    end
    function wrapper:resolve(speciesId, variant, targetGame)
      local art = ART[speciesId]
      if art then
        local shiny = variant == true or tostring(variant or ""):lower() == "shiny"
        return {
          id="SPRITE_RED_EARTH_"..tostring(speciesId)..(shiny and "_SHINY" or ""),
          image=shiny and art.followerShiny or art.follower,
          frames=6,
          walker=true,
          trueColor=true,
          frameWidth=16,
          frameHeight=16,
          anchorX=8,
          anchorY=15,
        }, {
          providerId="pokedex",
          providerMod=mod.id,
          usedVariant=shiny and "shiny" or "normal",
          bodyRenderer="NATIVE_SPRITE_RENDERER",
        }, nil
      end
      if type(base.resolve)=="function" then
        return base:resolve(speciesId, variant, targetGame)
      end
      return nil, nil, "no follower sprite"
    end

    local okRegister, registered = pcall(ex.registerSpriteProvider, "pokedex", wrapper)
    if okRegister and registered ~= false then
      followerInstalled = true
      if type(ex.refreshAllEntitySprites)=="function" then
        pcall(ex.refreshAllEntitySprites, game)
      end
    end
  end

  mod.events:on("game.ready", function(ev)
    local game = (ev and ev.game) or mod.game
    allMons(game and game.save, ensureMetadata)
    installFollowerProvider(game)
  end)
  pcall(installFollowerProvider, mod.game)

  -- Evolution mutates the original mon in Gen1Recomp. Reassert metadata and
  -- the explicit shiny flag without recreating the Pokemon object.
  mod.events:on("pokemon.evolved", function(ev)
    local mon = ev and ev.mon
    if isIrregular(mon) then ensureMetadata(mon) end
  end)

  -- Keep the original Oak scene/wording; only make the speaker explicit on
  -- the two unlabeled lines authored by Irregular Origin.
  local OAK_LABEL = {
    ["This one isn't from\nany region I know.\fIt was found where\nrecords end."] =
      "OAK: This one isn't\nfrom any region I know.\fIt was found where\nrecords end.",
    ["It is unlike any\nPOKéMON we've ever\nstudied.\fI'll leave the rest\nto you."] =
      "OAK: It is unlike any\nPOKéMON we've ever\nstudied.\fI'll leave the rest\nto you.",
  }
  mod.hooks:wrap("script.command", function(next, ctx, name, args, ...)
    if name == "show_text" and type(args)=="table"
       and ctx and ctx.source and ctx.source.modId == "irregular_origin"
       and type(args[1]) == "string" and OAK_LABEL[args[1]] then
      local rewritten = {}
      for i,v in ipairs(args) do rewritten[i]=v end
      rewritten[1] = OAK_LABEL[args[1]]
      return next(ctx, name, rewritten, ...)
    end
    return next(ctx, name, args, ...)
  end, 300)

  -- -------------------------- Nature + passives --------------------------
  local distanceReady = setmetatable({}, { __mode="k" })
  local activeBattle = nil

  local function armDistance(battler)
    local mon = battler and battler.mon
    if isIrregular(mon) then distanceReady[mon] = true end
  end

  local function consciousCount(game)
    local n = 0
    for _,mon in ipairs(game and game.save and game.save.party or {}) do
      if (tonumber(mon.hp) or 0) > 0 then n = n + 1 end
    end
    return n
  end

  local function reignActive(battle, battler)
    local mon = battler and battler.mon
    if not (battle and battler and mon and mon.species == IDS.SOLIPSDION) then
      return false
    end
    -- Solitary Reign is a player-party passive; party slot and follower state
    -- are irrelevant. It activates whenever Solipsdion is the sole conscious
    -- party member and deactivates as soon as another member is conscious.
    if battler ~= battle.player then return false end
    return consciousCount(mod.game) == 1
  end

  local function category(move)
    local c = tostring(move and move.category or ""):lower()
    if c == "physical" or c == "special" then return c end
    local t = tostring(move and move.type or ""):upper()
    return SPECIAL_TYPES[t] and "special" or "physical"
  end

  local function cloneBattler(b)
    if type(b) ~= "table" then return b end
    local c = {}
    for k,v in pairs(b) do c[k]=v end
    if type(b.curStats)=="table" then
      c.curStats={}
      for k,v in pairs(b.curStats) do c.curStats[k]=v end
    end
    if type(b.stages)=="table" then
      c.stages={}
      for k,v in pairs(b.stages) do c.stages[k]=v end
    end
    return c
  end

  local function prepareForDamage(battle, battler, cat, asUser)
    local mon = battler and battler.mon
    if not isIrregular(mon) then return battler end
    ensureMetadata(mon)
    local modest = mon.redEarthNature == "MODEST"
    local reign = reignActive(battle, battler)
    if not modest and not reign then return battler end

    local out = cloneBattler(battler)
    out.curStats = out.curStats or {}
    out.stages = out.stages or {}

    if modest then
      if asUser and cat == "physical" and tonumber(out.curStats.attack) then
        out.curStats.attack = math.max(1, math.floor(out.curStats.attack * 0.90))
      end
      if cat == "special" and tonumber(out.curStats.special) then
        out.curStats.special = math.max(1, math.floor(out.curStats.special * 1.10))
      end
    end

    if reign then
      if cat == "special" and tonumber(out.curStats.special) then
        out.curStats.special = math.max(1, math.floor(out.curStats.special * 1.20))
      end
      if (tonumber(out.stages.special) or 0) < 0 then out.stages.special = 0 end
    end
    return out
  end

  mod.events:on("battle.started", function(ev)
    local battle = ev and ev.battle
    if not battle then return end
    activeBattle = battle
    armDistance(battle.player)
    armDistance(battle.enemy)
  end)

  mod.events:on("battle.battler_switched", function(ev)
    armDistance(ev and ev.battler)
  end)

  mod.events:on("battle.ended", function(ev)
    if not ev or not ev.battle or ev.battle == activeBattle then activeBattle=nil end
  end)

  -- Modest and Solitary Reign are represented by temporary stat views passed
  -- into vanilla damage calculation. Distance is applied after vanilla damage
  -- and consumes only on the first positive damaging hit after entry.
  mod.hooks:wrap("battle.damage", function(next, ctx)
    if type(ctx) ~= "table" then return next(ctx) end
    local battle = ctx.battle
    local cat = category(ctx.move)
    local rewritten = {}
    for k,v in pairs(ctx) do rewritten[k]=v end
    rewritten.user = prepareForDamage(battle, ctx.user, cat, true)
    rewritten.target = prepareForDamage(battle, ctx.target, cat, false)

    local damage, info = next(rewritten)
    if type(damage) ~= "number" or damage <= 0 then return damage, info end

    local targetMon = ctx.target and ctx.target.mon
    if isIrregular(targetMon) and distanceReady[targetMon] then
      distanceReady[targetMon] = nil
      damage = math.max(1, math.floor(damage * 0.75))
    end
    return damage, info
  end, 300)

  -- Speed +20% and immunity to negative Speed stages while Reign is active.
  mod.hooks:wrap("battle.turn_order", function(next, a, aMove, b, bMove, ctx)
    local battle = (ctx and ctx.battle) or activeBattle
    local function speedView(x)
      if not reignActive(battle, x) then return x end
      local out = cloneBattler(x)
      out.curStats = out.curStats or {}
      out.stages = out.stages or {}
      if tonumber(out.curStats.speed) then
        out.curStats.speed = math.max(1, math.floor(out.curStats.speed * 1.20))
      end
      if (tonumber(out.stages.speed) or 0) < 0 then out.stages.speed = 0 end
      return out
    end
    return next(speedView(a), aMove, speedView(b), bMove, ctx)
  end, 300)

  -- Negative Special/Speed stages never survive a completed turn under Reign.
  -- Damage and turn-order hooks above already ignore them immediately while
  -- the passive is active, so this also keeps the stored battle state clean.
  mod.events:on("battle.turn_ended", function(ev)
    local battle = ev and ev.battle
    local battler = battle and battle.player
    if not reignActive(battle, battler) then return end
    battler.stages = battler.stages or {}
    if (tonumber(battler.stages.special) or 0) < 0 then battler.stages.special=0 end
    if (tonumber(battler.stages.speed) or 0) < 0 then battler.stages.speed=0 end
  end)

  mod.exports.version = "1.0.0"
  mod.exports.species = IDS
  mod.exports.isIrregular = isIrregular
  mod.exports.isShiny = isVisualShiny
  mod.exports.nature = function(mon)
    return isIrregular(mon) and (mon.redEarthNature or "MODEST") or nil
  end
  mod.exports.distanceArmed = function(mon) return distanceReady[mon] == true end
  mod.exports.reignActive = function()
    local battle = activeBattle
    return battle and reignActive(battle, battle.player) or false
  end
end
