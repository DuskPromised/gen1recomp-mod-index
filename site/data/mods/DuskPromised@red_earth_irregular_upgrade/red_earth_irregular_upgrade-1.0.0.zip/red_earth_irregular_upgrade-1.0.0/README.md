# Red Earth Irregular Upgrade v1.0.0

A **separate compatibility/upgrade mod** layered on top of the known-good `irregular_origin` v1.0.9. It does not merge or replace Philosopher Stones, Kaizo Bridge, Wilds, player skins, or rival systems.

This first recovery-layer upgrade adds only:

- final canonical Psydren/Vesperis/Solipsdion normal and shiny art
- final front/back/menu/icon routing
- final follower sheets through Wilds' existing provider
- stage-specific battle scale
- genuine shiny-state preservation for the Irregular line
- persistent `MODEST` metadata and a Gen-1 mechanical nature layer
- **Distance**
- **Solitary Reign**
- clearer `OAK:` attribution on the two previously unlabeled Irregular-Origin lines

Stone mechanics, Ansem, Melony, shiny-system bridging for the two non-Irregular starters, and Aetheric Transmutation are intentionally **not** in this mod. Those remain separate layers.
