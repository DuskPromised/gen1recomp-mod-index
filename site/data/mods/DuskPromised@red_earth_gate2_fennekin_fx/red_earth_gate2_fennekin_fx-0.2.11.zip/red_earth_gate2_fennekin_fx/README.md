# red_earth_gate2_fennekin_fx 0.2.11

Status: CANDIDATE, local only; Gate 2 remains PARTIAL GREEN.

Player-only marked shiny Fennekin-line entrance sparkle and existing Crystal sound. No sprite routing or scaling changes.

Dependencies: red_earth_gate2_fennekin_recovery@0.2.11, crystal_animated_sprites_with_shiny_visuals@2.0.3, red_earth_gate2_presentation@0.2.0, red_earth_gate2_sparkle_gold_lilac@0.2.4.

Install this ZIP through the engine mod importer before launching the local 0.2.11 cart. Preserve all 12 verified composite 0.2.9 modules, especially starter 0.2.6. No new art or sound files are supplied; exact baseline dependency assets are required and checked by build.py.

Tests use the pinned native engine with headless graphics/audio doubles. On-device fresh-save, UI, audible timing, persistence, evolution, and protected custom-line regression acceptance remain required. Do not publish before acceptance.
