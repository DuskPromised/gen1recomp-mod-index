-- Player-only effects for the marked Fennekin line. No sprite/scale hooks.
local Stats = require("src.pokemon.Stats")
local Assets = require("src.render.Assets")
local unpack = table.unpack or unpack
local function pack(...) return {n=select("#", ...), ...} end
local LINE = {FENNEKIN=true, BRAIXEN=true, DELPHOX=true}
local SEQUENCE = {{6,-8,-18,1},{14,12,-12,1},{22,18,8,1},{30,2,19,1},
  {38,-19,12,1},{46,-22,-7,1},{54,-4,-1,2}}

return function(mod)
  local crystal = assert(mod:find("crystal_animated_sprites_with_shiny_visuals"))
  assert(crystal.version == "2.0.3", "Fennekin FX requires Crystal 2.0.3")
  -- Same installed asset root used by the protected presentation 0.2.0 module.
  local root = "mods/crystal_animated_sprites_with_shiny_visuals/assets/shiny_visuals/"
  local installed = setmetatable({}, {__mode="k"})
  local image, quads
  local function eligible(battle, battler)
    local mon = battler and battler.mon
    return battle and battler == battle.player and mon and LINE[mon.species]
      and mon.redEarthGate25StarterShiny == true and Stats.isShiny(mon.dvs)
  end
  local function draw(fx, battler, x, y, scale)
    local img = battler.sprite
    if not img then return end
    if not image then
      image = love.graphics.newImage(Assets.resolve(root .. "gen2_sparkles.png"))
      image:setFilter("nearest", "nearest")
      quads = {}
      for i=0,3 do quads[i+1]=love.graphics.newQuad(i*16,0,16,16,64,16) end
    end
    local t = (love.timer.getTime() - fx.started) * 60
    local g = love.graphics
    g.push("all")
    g.setColor(1,1,1,1)
    for _, v in ipairs(SEQUENCE) do
      local age = t-v[1]
      if age >= 0 and age < 24 then
        local frame = age<4 and 1 or age<9 and 2 or age<15 and 3 or age<20 and 4 or 1
        g.draw(image, quads[frame], math.floor(x+img:getWidth()*scale/2+v[2]*scale),
          math.floor(y+img:getHeight()*scale/2+v[3]*scale), 0, v[4],v[4],8,8)
      end
    end
    g.pop()
  end
  local function install(battle)
    if not battle or installed[battle] then return end
    local fx
    local function clear()
      if fx and fx.source then fx.source:stop() end
      if fx and fx.crySource then fx.crySource:stop() end
      fx = nil
    end
    installed[battle] = clear
    local innerCry = battle.playEntranceCry
    battle.playEntranceCry = function(self, battler, ...)
      if not eligible(self, battler) then return innerCry(self, battler, ...) end
      -- Keep the completed record until the next send-out/switch, preventing replay.
      if fx and fx.battler == battler and fx.mon == battler.mon then
        return fx.waiter
      end
      clear()
      local ok, source = pcall(love.audio.newSource,
        Assets.resolve(root .. "gen2_shiny_sparkle.mp3"), "static")
      if not ok or not source then return innerCry(self, battler, ...) end
      fx = {battler=battler, mon=battler.mon, source=source,
        started=love.timer.getTime(), args=pack(...)}
      local record = fx
      -- Native waitSfxNext accepts a source-like object. Hold the existing wait
      -- through both sounds without inserting/reordering any native queue rows.
      fx.waiter = {
        isPlaying = function()
          if fx ~= record then return false end
          if not record.cried then return true end
          return record.crySource and record.crySource:isPlaying() or false
        end,
        stop = function() if fx == record then clear() end end,
      }
      source:setLooping(false)
      source:play()
      return fx.waiter
    end
    local innerPic = battle.drawBattlerPic
    battle.drawBattlerPic = function(self, battler, x, y, scale, ...)
      local result = pack(innerPic(self, battler, x, y, scale, ...))
      if fx and fx.battler == battler and fx.mon == battler.mon
          and eligible(self, battler) and love.timer.getTime()-fx.started < 1.5 then
        draw(fx, battler, x, y, scale)
      end
      return unpack(result, 1, result.n)
    end
    local innerUpdate = battle.update
    battle.update = function(self, ...)
      -- Handle audio completion before the native queue checks the waiting source.
      if fx then
        if fx.battler ~= self.player or fx.mon ~= self.player.mon
            or not eligible(self, self.player) then
          clear()
        elseif not fx.cried and not fx.source:isPlaying() then
          fx.cried = true
          fx.crySource = innerCry(self, fx.battler, unpack(fx.args,1,fx.args.n))
        end
      end
      return innerUpdate(self, ...)
    end
    local innerSend = battle.queueSendOutAnim
    battle.queueSendOutAnim = function(self, ...)
      clear()
      return innerSend(self, ...)
    end
    local innerExit = battle.exit
    battle.exit = function(self, ...)
      clear()
      return innerExit(self, ...)
    end
  end
  mod.events:on("battle.started", function(ev) install(ev and ev.battle) end, -25)
  mod.events:on("battle.battler_switched", function(ev)
    local battle = ev and ev.battle
    if battle and ev.battler == battle.player and installed[battle] then installed[battle]() end
  end, -25)
  mod.events:on("battle.ended", function(ev)
    local clear = ev and installed[ev.battle]
    if clear then clear() end
  end, -25)
  mod.exports.version = "0.2.11"
end
