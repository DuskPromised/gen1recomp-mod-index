-- Additive adapter for the verified 0.2.6 starter module. No asset overrides.
local Party = require("src.pokemon.Party")
local Assets = require("src.render.Assets")
local Sprites = require("src.pokemon.Sprites")
local unpack = table.unpack or unpack
local function pack(...) return { n=select("#", ...), ... } end

return function(mod)
  local starter = assert(mod:find("red_earth_gate2_starter_shiny_state_icons"))
  assert(starter.exports.version == "0.2.6", "Fennekin requires verified starter 0.2.6")
  local scopes = setmetatable({}, {__mode="k"})
  local mainThread = {}
  local function thread() return coroutine.running() or mainThread end
  local function pending(ctx)
    local flags = ctx and ctx.save and ctx.save.flags
    local map = ctx and ctx.overworld and ctx.overworld.map
    local mapId = map and map.id or (ctx and ctx.source and ctx.source.mapId)
    return mapId == "OAKS_LAB" and flags
      and flags.EVENT_FOLLOWED_OAK_INTO_LAB == true
      and flags.EVENT_GOT_STARTER ~= true
  end

  local innerAdd = Party.add
  Party.add = function(party, mon, ...)
    local scope = scopes[thread()]
    if scope and scope.kind == "gift" and pending(scope.ctx)
        and party == scope.ctx.save.party and type(mon) == "table"
        and mon.species == "FENNEKIN" and mon.level == 5
        and not scope.seen[mon] then
      -- Consume before calling any downstream code, including nickname UI.
      scopes[thread()] = nil
      assert(starter.exports.makeGuaranteedShiny(mon, scope.ctx.game),
        "Fennekin shiny identity failed")
    end
    -- Exact argument/result forwarding, including false for box fallback.
    return innerAdd(party, mon, ...)
  end

  mod.events:on("screen.pushed", function(ev)
    local key = thread()
    local scope = scopes[key]
    local state = ev and ev.state
    if not (scope and scope.kind == "preview" and state
        and state.screenId == "DexEntryMenu" and state.game == scope.ctx.game
        and state.species == "FENNEKIN" and state.forceOwned == true) then return end
    scopes[key] = nil
    -- Only this native screen instance changes. The actual mon does not yet exist.
    local path = Sprites.path(state.game.data, "FENNEKIN", "front", {
      kind="dex", mon={species="FENNEKIN", shiny=true, dvs=starter.exports.shinyDVs()},
    })
    local image = love.graphics.newImage(Assets.resolve(path))
    state.sprite, state.spriteTrueColor = image, true
  end, -25)

  mod.hooks:wrap("script.command", function(nextCmd, ctx, name, args, ...)
    if not (type(args) == "table" and pending(ctx)) then
      return nextCmd(ctx, name, args, ...)
    end
    local kind
    if name == "give_pokemon" and args[1] == "FENNEKIN"
        and tonumber(args[2]) == 5 then
      kind = "gift"
    elseif name == "push_screen" and args[1] == "DexEntryMenu"
        and type(args[2]) == "table" and args[2].species == "FENNEKIN"
        and args[2].forceOwned == true then
      kind = "preview"
    end
    if not kind then return nextCmd(ctx, name, args, ...) end
    local key = thread()
    local previous = scopes[key]
    local seen = {}
    if kind == "gift" then
      for _, mon in ipairs(ctx.save.party or {}) do seen[mon] = true end
      for _, box in ipairs(ctx.save.boxes or {}) do
        for _, mon in ipairs(box) do seen[mon] = true end
      end
      for _, mon in ipairs(ctx.save.box or {}) do seen[mon] = true end
    end
    scopes[key] = {kind=kind, ctx=ctx, seen=seen}
    local result = pack(pcall(nextCmd, ctx, name, args, ...))
    scopes[key] = previous
    if not result[1] then error(result[2], 0) end
    return unpack(result, 2, result.n)
  end, -25) -- Kaizo resolves the regional species at priority 0 first.

  mod.exports.version = "0.2.11"
end
