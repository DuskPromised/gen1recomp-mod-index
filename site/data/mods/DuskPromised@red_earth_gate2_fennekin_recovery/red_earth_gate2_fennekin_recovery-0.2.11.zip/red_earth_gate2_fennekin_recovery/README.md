# red_earth_gate2_fennekin_recovery 0.2.11

Status: CANDIDATE, local only; Gate 2 remains PARTIAL GREEN.

Scoped pre-insertion Fennekin shiny identity and instance-only Oak preview. Native acquisition/nickname flow and baseline assets unchanged.

Dependencies: gen1_kaizo@0.8.3, red_earth_gate2_starter_shiny_state_icons@0.2.6.

Install this ZIP through the engine mod importer before launching the local 0.2.11 cart. Preserve all 12 verified composite 0.2.9 modules, especially starter 0.2.6. No new art or sound files are supplied; exact baseline dependency assets are required and checked by build.py.

Tests use the pinned native engine with headless graphics/audio doubles. On-device fresh-save, UI, audible timing, persistence, evolution, and protected custom-line regression acceptance remain required. Do not publish before acceptance.
